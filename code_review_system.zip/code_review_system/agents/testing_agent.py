from agents.base_agent import BaseAgent, AgentInput, AgentOutput


class TestingAgent(BaseAgent):
    """
    Test coverage and quality agent.
    
    Identifies:
    - Missing test cases
    - Untested edge cases
    - Test quality issues
    - Mock/stub opportunities
    """
    
    def __init__(self, llm_client):
        super().__init__("testing_agent", llm_client)
    
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """Analyze code for testing gaps"""
        
        prompt = f"""You are a testing expert analyzing code coverage and test quality.

CODE:
```python
{input_data.chunk.content}
```

TASK:
Identify testing gaps and opportunities:
1. Missing unit tests for functions/methods
2. Untested edge cases (null, empty, boundary values)
3. Missing error condition tests
4. Integration test opportunities
5. Test quality issues (if test code)
6. Mock/stub recommendations

For each gap, provide:
- Description of what should be tested
- Severity (medium/low)
- Example test case
- Confidence score

Return JSON format.
"""
        
        response = await self._call_llm(prompt)
        issues = self._parse_response(response, input_data)
        
        return AgentOutput(
            agent_name=self.name,
            issues=issues,
            confidence=response.get('overall_confidence', 0.8),
            reasoning=response.get('reasoning', ''),
            cost=self._calculate_cost(prompt, response)
        )