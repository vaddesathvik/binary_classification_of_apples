from agents.base_agent import BaseAgent, AgentInput, AgentOutput


class SyntaxAgent(BaseAgent):
    """
    Syntax and correctness agent.
    
    Uses the most cost-efficient model since this is straightforward.
    
    Identifies:
    - Syntax errors
    - Type errors
    - Import errors
    - Undefined variables
    """
    
    def __init__(self, llm_client):
        super().__init__("syntax_agent", llm_client)
    
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """Analyze code for syntax issues"""
        
        # Get pylint errors
        pylint_errors = [
            f for f in input_data.static_findings
            if f.tool == 'pylint' and f.severity in ['error', 'fatal']
        ]
        
        prompt = f"""You are a syntax checker analyzing code correctness.

CODE:
```python
{input_data.chunk.content}
```

STATIC ERRORS:
{json.dumps([f.__dict__ for f in pylint_errors], indent=2)}

TASK:
Identify syntax and correctness issues:
1. Syntax errors
2. Undefined variables
3. Import errors
4. Type mismatches
5. Missing return statements
6. Unreachable code

Return JSON format with issues array.
"""
        
        response = await self._call_llm(prompt)
        issues = self._parse_response(response, input_data)
        
        return AgentOutput(
            agent_name=self.name,
            issues=issues,
            confidence=response.get('overall_confidence', 0.9),
            reasoning=response.get('reasoning', ''),
            cost=self._calculate_cost(prompt, response)
        )
