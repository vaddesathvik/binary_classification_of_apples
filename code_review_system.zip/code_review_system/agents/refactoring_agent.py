from agents.base_agent import BaseAgent, AgentInput, AgentOutput


class RefactoringAgent(BaseAgent):
    """
    Code refactoring opportunities agent.
    
    Identifies:
    - Code duplication
    - Long methods/classes
    - Feature envy
    - God objects
    - Primitive obsession
    """
    
    def __init__(self, llm_client):
        super().__init__("refactoring_agent", llm_client)
    
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """Analyze code for refactoring opportunities"""
        
        # Get complexity metrics
        complexity = input_data.chunk.complexity
        
        prompt = f"""You are a refactoring expert analyzing code maintainability.

CODE:
```python
{input_data.chunk.content}
```

COMPLEXITY: {complexity}

TASK:
Identify refactoring opportunities:
1. Long methods (>50 lines) - extract method
2. Code duplication - extract common logic
3. Feature envy - move methods to appropriate class
4. Large classes - split responsibilities
5. Primitive obsession - introduce value objects
6. Switch statements - use polymorphism
7. Dead code - remove unused code

For each opportunity:
- Description of smell
- Refactoring pattern to apply
- Expected benefit
- Refactored code example (if simple)
- Confidence score

Return JSON format.
"""
        
        response = await self._call_llm(prompt)
        issues = self._parse_response(response, input_data)
        
        return AgentOutput(
            agent_name=self.name,
            issues=issues,
            confidence=response.get('overall_confidence', 0.8),
            reasoning=response.get('reasoning', ''),
            cost=self._calculate_cost(prompt, response)
        )