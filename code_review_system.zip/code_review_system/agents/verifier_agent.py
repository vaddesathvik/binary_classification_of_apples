class VerifierAgent(BaseAgent):
    """
    CRITICAL: Verifies all agent outputs to prevent hallucinations.
    
    Verification strategy:
    1. Check for tool evidence (static analysis backing)
    2. Check multi-agent consensus
    3. Verify against dependency graph
    4. Validate code references actually exist
    5. Assign final confidence score
    """
    
    def __init__(self, llm_client: Any):
        super().__init__("verifier_agent", llm_client)
        self.min_confidence = 0.7
        self.consensus_threshold = 0.6
    
    async def verify_issues(
        self,
        all_agent_outputs: List[AgentOutput],
        static_findings: List[ToolFinding],
        chunk: 'CodeChunk'
    ) -> List['Issue']:
        """
        Verify and filter issues from all agents.
        
        Args:
            all_agent_outputs: Outputs from all analysis agents
            static_findings: Findings from static tools
            chunk: Code chunk being analyzed
            
        Returns:
            Verified issues with confidence scores
        """
        verified_issues = []
        
        # Group issues by location
        issues_by_location = {}
        for output in all_agent_outputs:
            for issue in output.issues:
                key = f"{issue.location.file_path}:{issue.location.start_line}"
                if key not in issues_by_location:
                    issues_by_location[key] = []
                issues_by_location[key].append((issue, output.agent_name))
        
        # Verify each issue
        for location, issue_list in issues_by_location.items():
            verified = await self._verify_issue_group(
                issue_list,
                static_findings,
                chunk
            )
            if verified:
                verified_issues.extend(verified)
        
        return verified_issues
    
    async def _verify_issue_group(
        self,
        issues: List[tuple['Issue', str]],
        static_findings: List[ToolFinding],
        chunk: 'CodeChunk'
    ) -> List['Issue']:
        """Verify a group of issues at the same location"""
        
        verified = []
        
        for issue, agent_name in issues:
            # Check 1: Tool evidence
            has_tool_evidence = any(
                e.source in ['pylint', 'bandit', 'radon', 'semgrep']
                for e in issue.evidence
            )
            
            # Check 2: Multi-agent consensus
            same_location_issues = [i for i, _ in issues]
            consensus_score = len(same_location_issues) / len(issues)
            
            # Check 3: Code reference validation
            code_exists = self._validate_code_reference(issue, chunk)
            
            # Calculate final confidence
            base_confidence = issue.confidence
            
            if has_tool_evidence:
                base_confidence *= 1.2  # Boost for tool backing
            
            if consensus_score >= self.consensus_threshold:
                base_confidence *= 1.1  # Boost for consensus
            
            if not code_exists:
                base_confidence *= 0.5  # Penalize invalid references
            
            # Cap at 1.0
            final_confidence = min(base_confidence, 1.0)
            
            # Accept if above threshold
            if final_confidence >= self.min_confidence:
                issue.confidence = final_confidence
                verified.append(issue)
        
        return verified
    
    def _validate_code_reference(
        self,
        issue: 'Issue',
        chunk: 'CodeChunk'
    ) -> bool:
        """Validate that issue references actual code"""
        try:
            lines = chunk.content.splitlines()
            ref_line = issue.location.start_line - chunk.start_line
            
            if 0 <= ref_line < len(lines):
                return True
            return False
        except:
            return False