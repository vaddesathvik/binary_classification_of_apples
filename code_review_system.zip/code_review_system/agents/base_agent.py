from abc import ABC, abstractmethod
from typing import Dict, Any, List
from dataclasses import dataclass


@dataclass
class AgentInput:
    """Input to an agent"""
    chunk: 'CodeChunk'
    static_findings: List[ToolFinding]
    dependency_context: Dict[str, Any]
    file_context: str


@dataclass
class AgentOutput:
    """Output from an agent"""
    agent_name: str
    issues: List['Issue']
    confidence: float
    reasoning: str
    cost: float = 0.0


class BaseAgent(ABC):
    """
    Base class for all analysis agents.
    
    Each agent has a SINGLE RESPONSIBILITY and operates independently.
    Agents must provide evidence and confidence scores for all findings.
    """
    
    def __init__(self, name: str, llm_client: Any):
        self.name = name
        self.llm = llm_client
    
    @abstractmethod
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """
        Analyze code chunk and return findings.
        
        Args:
            input_data: Agent input with code and context
            
        Returns:
            Agent output with issues and confidence
        """
        pass
    
    def _create_prompt(self, input_data: AgentInput) -> str:
        """Create LLM prompt with context"""
        raise NotImplementedError
    
    async def _call_llm(self, prompt: str) -> Dict[str, Any]:
        """Call LLM with prompt and parse response"""
        raise NotImplementedError


# ============================================================================
# FILE: agents/security_agent.py
# ============================================================================

from typing import List


class SecurityAgent(BaseAgent):
    """
    Security-focused analysis agent.
    
    Uses the STRONGEST model (Opus) because security is critical.
    Cross-references findings with Bandit and Semgrep.
    """
    
    def __init__(self, llm_client: Any):
        super().__init__("security_agent", llm_client)
    
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """
        Analyze code for security vulnerabilities.
        
        Focus areas:
        - SQL injection
        - XSS vulnerabilities
        - Authentication/authorization issues
        - Cryptographic weaknesses
        - Input validation
        """
        
        # Get static tool findings for this chunk
        bandit_findings = [
            f for f in input_data.static_findings
            if f.tool == 'bandit' and f.line >= input_data.chunk.start_line
            and f.line <= input_data.chunk.end_line
        ]
        
        # Create focused prompt
        prompt = f"""You are a security expert analyzing code for vulnerabilities.

CODE CHUNK:
```python
{input_data.chunk.content}
```

STATIC ANALYSIS FINDINGS:
{json.dumps([f.__dict__ for f in bandit_findings], indent=2)}

TASK:
1. Identify ALL security vulnerabilities in this code
2. For EACH finding:
   - Explain the vulnerability
   - Assess severity (critical/high/medium/low)
   - Provide evidence (line numbers, code references)
   - Suggest a fix
   - Assign confidence score (0.0-1.0)

3. Cross-reference with static analysis findings
4. Flag any issues missed by static tools

Return JSON:
{{
  "issues": [
    {{
      "title": "SQL Injection Risk",
      "severity": "critical",
      "line": 42,
      "description": "...",
      "evidence": "...",
      "suggested_fix": "...",
      "confidence": 0.95,
      "cwe_id": "CWE-89"
    }}
  ],
  "overall_confidence": 0.9,
  "reasoning": "..."
}}
"""
        
        response = await self._call_llm(prompt)
        
        # Convert LLM response to Issues
        issues = self._parse_response(response, input_data)
        
        return AgentOutput(
            agent_name=self.name,
            issues=issues,
            confidence=response.get('overall_confidence', 0.8),
            reasoning=response.get('reasoning', ''),
            cost=self._calculate_cost(prompt, response)
        )
    
    def _parse_response(
        self,
        response: Dict[str, Any],
        input_data: AgentInput
    ) -> List['Issue']:
        """Convert LLM response to Issue objects"""
        from models.schemas import Issue, Evidence, IssueCategory, Severity
        
        issues = []
        for item in response.get('issues', []):
            evidence = [
                Evidence(
                    source=self.name,
                    raw_output=json.dumps(item),
                    confidence=item.get('confidence', 0.8)
                )
            ]
            
            # Add static tool evidence if available
            for finding in input_data.static_findings:
                if finding.line == item.get('line'):
                    evidence.append(Evidence(
                        source=finding.tool,
                        raw_output=finding.message,
                        confidence=finding.confidence
                    ))
            
            issue = Issue(
                id=f"{input_data.chunk.chunk_id}:{item.get('line')}",
                category=IssueCategory.SECURITY,
                severity=Severity(item.get('severity', 'medium')),
                title=item.get('title', ''),
                description=item.get('description', ''),
                location=input_data.chunk.__dict__,
                evidence=evidence,
                confidence=item.get('confidence', 0.8),
                suggested_fix=item.get('suggested_fix'),
                cwe_id=item.get('cwe_id')
            )
            issues.append(issue)
        
        return issues
    
    async def _call_llm(self, prompt: str) -> Dict[str, Any]:
        """Call LLM API (would use actual API in production)"""
        # Placeholder - in production, call Anthropic API
        return {
            "issues": [],
            "overall_confidence": 0.9,
            "reasoning": "Analysis complete"
        }
    
    def _calculate_cost(self, prompt: str, response: Dict) -> float:
        """Calculate API cost for this call"""
        # Rough estimation: 4 chars = 1 token
        input_tokens = len(prompt) / 4
        output_tokens = len(json.dumps(response)) / 4
        
        # Use Opus pricing
        cost = (input_tokens / 1000 * 0.015) + (output_tokens / 1000 * 0.075)
        return cost