class PerformanceAgent(BaseAgent):
    """
    Performance optimization agent.
    
    Focuses on:
    - Algorithm complexity
    - Memory usage
    - Database query optimization
    - Caching opportunities
    - Inefficient loops
    """
    
    def __init__(self, llm_client: Any):
        super().__init__("performance_agent", llm_client)
    
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """Analyze code for performance issues"""
        
        radon_findings = [
            f for f in input_data.static_findings
            if f.tool == 'radon'
        ]
        
        prompt = f"""You are a performance optimization expert.

CODE:
```python
{input_data.chunk.content}
```

COMPLEXITY ANALYSIS:
{json.dumps([f.__dict__ for f in radon_findings], indent=2)}

Identify performance issues:
1. Time complexity problems (O(n²) or worse)
2. Memory leaks or excessive memory usage
3. Inefficient database queries (N+1 problem)
4. Missing caching opportunities
5. Inefficient data structures

For each issue, provide:
- Description
- Current complexity
- Suggested optimization
- Expected improvement
- Confidence score

Return JSON format.
"""
        
        response = await self._call_llm(prompt)
        issues = self._parse_response(response, input_data)
        
        return AgentOutput(
            agent_name=self.name,
            issues=issues,
            confidence=response.get('overall_confidence', 0.85),
            reasoning=response.get('reasoning', ''),
            cost=self._calculate_cost(prompt, response)
        )
