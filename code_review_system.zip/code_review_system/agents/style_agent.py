from agents.base_agent import BaseAgent, AgentInput, AgentOutput
from typing import List
import json


class StyleAgent(BaseAgent):
    """
    Code style and best practices agent.
    
    Focuses on:
    - PEP 8 compliance (Python)
    - Naming conventions
    - Code organization
    - Documentation quality
    - Design patterns
    """
    
    def __init__(self, llm_client):
        super().__init__("style_agent", llm_client)
    
    async def analyze(self, input_data: AgentInput) -> AgentOutput:
        """Analyze code for style issues"""
        
        # Get pylint findings (style-related)
        pylint_findings = [
            f for f in input_data.static_findings
            if f.tool == 'pylint' and f.category in ['convention', 'refactor']
        ]
        
        prompt = f"""You are a code style expert analyzing for best practices.

CODE:
```python
{input_data.chunk.content}
```

STATIC ANALYSIS (Pylint style findings):
{json.dumps([f.__dict__ for f in pylint_findings], indent=2)}

TASK:
Identify style and best practice issues:
1. Naming conventions (variables, functions, classes)
2. Code organization and structure
3. Documentation quality (docstrings, comments)
4. PEP 8 compliance
5. Design pattern violations
6. Magic numbers and hardcoded values
7. Code duplication

For each issue, provide:
- Description
- Severity (low/info)
- Line number
- Suggested improvement
- Confidence score

Return JSON format:
{{
  "issues": [...],
  "overall_confidence": 0.85,
  "reasoning": "..."
}}
"""
        
        response = await self._call_llm(prompt)
        issues = self._parse_response(response, input_data)
        
        return AgentOutput(
            agent_name=self.name,
            issues=issues,
            confidence=response.get('overall_confidence', 0.85),
            reasoning=response.get('reasoning', ''),
            cost=self._calculate_cost(prompt, response)
        )