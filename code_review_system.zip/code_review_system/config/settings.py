from pydantic_settings import BaseSettings
from typing import Dict, List
from functools import lru_cache


class Settings(BaseSettings):
    """
    Production configuration with environment-based overrides.
    """
    
    # API Configuration
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_WORKERS: int = 4
    
    # LLM Provider Configuration
    OPENAI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    
    # Model Configuration
    PRIMARY_MODEL: str = "claude-sonnet-4-20250514"  # Best for reasoning
    SECURITY_MODEL: str = "claude-opus-4-20250514"   # Most powerful
    PERFORMANCE_MODEL: str = "gpt-4"                 # Code-specialized
    REFACTOR_MODEL: str = "claude-sonnet-4-20250514"
    
    # Processing Configuration
    MAX_CHUNK_SIZE: int = 2000  # Lines per chunk
    MAX_CONCURRENT_AGENTS: int = 6
    MAX_CONCURRENT_FILES: int = 10
    
    # Verification Configuration
    MIN_CONFIDENCE_THRESHOLD: float = 0.7
    REQUIRE_TOOL_EVIDENCE: bool = True
    REQUIRE_MULTI_AGENT_CONSENSUS: bool = True
    CONSENSUS_THRESHOLD: float = 0.6  # 60% agent agreement
    
    # Static Analysis Tools
    ENABLE_PYLINT: bool = True
    ENABLE_BANDIT: bool = True
    ENABLE_RADON: bool = True
    ENABLE_SEMGREP: bool = True
    
    # Storage Configuration
    DATABASE_URL: str = "postgresql://localhost/code_review"
    REDIS_URL: str = "redis://localhost:6379"
    
    # Supported Languages
    SUPPORTED_LANGUAGES: List[str] = [
        "python", "java", "javascript", "typescript",
        "cpp", "c", "go", "rust"
    ]
    
    # File Filters
    IGNORED_PATTERNS: List[str] = [
        "*.pyc", "__pycache__", "node_modules",
        ".git", "*.min.js", "dist", "build"
    ]
    
    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()