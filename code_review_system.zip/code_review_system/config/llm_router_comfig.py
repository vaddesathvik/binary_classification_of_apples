from enum import Enum
from typing import Dict


class TaskType(str, Enum):
    SECURITY = "security"
    PERFORMANCE = "performance"
    REFACTORING = "refactoring"
    TESTING = "testing"
    SYNTAX = "syntax"
    STYLE = "style"


class ModelCapability(str, Enum):
    REASONING = "reasoning"
    CODE_GENERATION = "code_generation"
    PATTERN_RECOGNITION = "pattern_recognition"
    COST_EFFICIENT = "cost_efficient"


# Task -> Model routing policy
TASK_MODEL_MAPPING: Dict[TaskType, str] = {
    TaskType.SECURITY: "claude-opus-4-20250514",      # Highest accuracy
    TaskType.PERFORMANCE: "gpt-4",                     # Code optimization
    TaskType.REFACTORING: "claude-sonnet-4-20250514", # Balanced
    TaskType.TESTING: "claude-sonnet-4-20250514",
    TaskType.SYNTAX: "gpt-3.5-turbo",                 # Cost-efficient
    TaskType.STYLE: "gpt-3.5-turbo",
}

# Model cost per 1K tokens (input/output)
MODEL_COSTS: Dict[str, Dict[str, float]] = {
    "claude-opus-4-20250514": {"input": 0.015, "output": 0.075},
    "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015},
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
}