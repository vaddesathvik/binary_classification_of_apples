from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from pathlib import Path


@dataclass
class WorkflowState:
    """
    Shared state across the entire workflow.
    This is passed between all workflow stages.
    """
    # Input
    analysis_id: str
    source_type: str
    source_location: str
    
    # Ingestion stage
    repository_path: Optional[Path] = None
    files_to_analyze: List[Path] = field(default_factory=list)
    languages_detected: Dict[str, int] = field(default_factory=dict)
    
    # Chunking stage
    chunks: List[Any] = field(default_factory=list)  # List[CodeChunk]
    dependency_graph: Optional[Any] = None  # DependencyGraph
    
    # Static analysis stage
    static_findings: Dict[str, List[Any]] = field(default_factory=dict)
    
    # Agent analysis stage
    agent_outputs: List[Any] = field(default_factory=list)  # List[AgentOutput]
    
    # Verification stage
    verified_issues: List[Any] = field(default_factory=list)  # List[Issue]
    
    # Aggregation stage
    file_analyses: List[Any] = field(default_factory=list)  # List[FileAnalysis]
    
    # Final output
    result: Optional[Any] = None  # RepositoryAnalysis
    
    # Metadata
    total_cost: float = 0.0
    processing_start_time: float = 0.0
    current_stage: str = "initialized"
    error: Optional[str] = None