import asyncio
import time
from pathlib import Path
from typing import List, Dict
import logging

from config.settings import Settings
from ingestion.repository_loader import LoaderFactory
from ingestion.language_detector import LanguageDetector
from ingestion.file_filter import FileFilter
from chunking.ast_parser import ASTParser
from chunking.dependency_graph import DependencyGraph
from chunking.chunk_metadata import ChunkMetadataStore
from static_analysis.tool_executor import ToolExecutor
from static_analysis.normalizer import FindingNormalizer
from agents.security_agent import SecurityAgent
from agents.performance_agent import PerformanceAgent
from agents.style_agent import StyleAgent
from agents.testing_agent import TestingAgent
from agents.refactoring_agent import RefactoringAgent
from agents.syntax_agent import SyntaxAgent
from agents.verifier_agent import VerifierAgent
from agents.base_agent import AgentInput
from llm_routing.router import MultiLLMRouter
from aggregation.chunk_aggregator import ChunkAggregator
from aggregation.file_aggregator import FileAggregator
from aggregation.module_aggregator import ModuleAggregator
from aggregation.system_aggregator import SystemAggregator
from orchestration.state import WorkflowState
from models.schemas import RepositoryAnalysis, AnalysisRequest
from utils.metrics import MetricsCollector


logger = logging.getLogger(__name__)


class CodeReviewWorkflow:
    """
    Main orchestration workflow.
    Coordinates all stages of the code review process.
    """
    
    def __init__(self, config: Settings):
        self.config = config
        
        # Initialize components
        self.language_detector = LanguageDetector()
        self.file_filter = FileFilter(config.IGNORED_PATTERNS)
        self.ast_parser = ASTParser()
        self.tool_executor = ToolExecutor()
        self.finding_normalizer = FindingNormalizer()
        self.chunk_metadata_store = ChunkMetadataStore(config.REDIS_URL)
        self.metrics = MetricsCollector()
        
        # Initialize LLM router
        self.llm_router = MultiLLMRouter(
            config.ANTHROPIC_API_KEY,
            config.OPENAI_API_KEY
        )
        
        # Initialize agents
        self.agents = {
            'security': SecurityAgent(self.llm_router),
            'performance': PerformanceAgent(self.llm_router),
            'style': StyleAgent(self.llm_router),
            'testing': TestingAgent(self.llm_router),
            'refactoring': RefactoringAgent(self.llm_router),
            'syntax': SyntaxAgent(self.llm_router)
        }
        
        self.verifier = VerifierAgent(self.llm_router)
        
        # Initialize aggregators
        self.chunk_aggregator = ChunkAggregator()
        self.file_aggregator = FileAggregator()
        self.module_aggregator = ModuleAggregator()
        self.system_aggregator = SystemAggregator()
    
    async def execute(self, request: AnalysisRequest) -> RepositoryAnalysis:
        """
        Execute complete analysis workflow.
        
        This is the main entry point for code analysis.
        """
        import uuid
        
        state = WorkflowState(
            analysis_id=str(uuid.uuid4()),
            source_type=request.source_type,
            source_location=request.source_location,
            processing_start_time=time.time()
        )
        
        try:
            logger.info(f"Starting analysis {state.analysis_id}")
            
            # Stage 1: Ingest code
            state.current_stage = "ingestion"
            await self._stage_ingestion(state, request)
            logger.info(f"Ingestion complete: {len(state.files_to_analyze)} files")
            
            # Stage 2: Chunk code
            state.current_stage = "chunking"
            await self._stage_chunking(state)
            logger.info(f"Chunking complete: {len(state.chunks)} chunks")
            
            # Stage 3: Static analysis
            state.current_stage = "static_analysis"
            await self._stage_static_analysis(state)
            logger.info("Static analysis complete")
            
            # Stage 4: Multi-agent analysis
            state.current_stage = "agent_analysis"
            await self._stage_agent_analysis(state)
            logger.info(f"Agent analysis complete: {len(state.agent_outputs)} outputs")
            
            # Stage 5: Verification
            state.current_stage = "verification"
            await self._stage_verification(state)
            logger.info(f"Verification complete: {len(state.verified_issues)} verified issues")
            
            # Stage 6: Aggregation
            state.current_stage = "aggregation"
            await self._stage_aggregation(state)
            logger.info("Aggregation complete")
            
            # Stage 7: Generate final result
            state.current_stage = "finalization"
            result = await self._stage_finalization(state)
            
            logger.info(f"Analysis {state.analysis_id} complete")
            return result
            
        except Exception as e:
            logger.error(f"Analysis {state.analysis_id} failed: {e}", exc_info=True)
            state.error = str(e)
            raise
    
    async def _stage_ingestion(self, state: WorkflowState, request: AnalysisRequest):
        """Stage 1: Load and filter code"""
        with self.metrics.measure_time("ingestion"):
            # Load repository
            loader = LoaderFactory.create_loader(request.source_type)
            state.repository_path = await loader.load(request.source_location)
            
            # Detect languages
            state.languages_detected = self.language_detector.get_file_statistics(
                state.repository_path
            )
            
            # Filter files
            supported_languages = set(self.config.SUPPORTED_LANGUAGES)
            state.files_to_analyze = self.file_filter.filter_files(
                state.repository_path,
                supported_languages,
                self.language_detector
            )
    
    async def _stage_chunking(self, state: WorkflowState):
        """Stage 2: Parse code into chunks and build dependency graph"""
        with self.metrics.measure_time("chunking"):
            all_chunks = []
            
            # Parse each file into chunks
            for file_path in state.files_to_analyze:
                try:
                    language = self.language_detector.detect(file_path)
                    
                    if language == "python":
                        chunks = self.ast_parser.parse_python_file(file_path)
                        all_chunks.extend(chunks)
                        
                        # Store chunk metadata
                        for chunk in chunks:
                            self.chunk_metadata_store.store_chunk(chunk)
                        
                        # Store file->chunks mapping
                        chunk_ids = [c.chunk_id for c in chunks]
                        self.chunk_metadata_store.store_file_chunks(
                            str(file_path),
                            chunk_ids
                        )
                except Exception as e:
                    logger.warning(f"Failed to parse {file_path}: {e}")
            
            state.chunks = all_chunks
            
            # Build dependency graph
            dep_graph = DependencyGraph()
            state.dependency_graph = dep_graph.build_from_chunks(all_chunks)
            
            self.metrics.increment_counter("chunks_created", len(all_chunks))
    
    async def _stage_static_analysis(self, state: WorkflowState):
        """Stage 3: Run static analysis tools"""
        with self.metrics.measure_time("static_analysis"):
            enabled_tools = []
            if self.config.ENABLE_PYLINT:
                enabled_tools.append("pylint")
            if self.config.ENABLE_BANDIT:
                enabled_tools.append("bandit")
            if self.config.ENABLE_RADON:
                enabled_tools.append("radon")
            
            # Run tools on all files in parallel
            tasks = []
            for file_path in state.files_to_analyze:
                tasks.append(
                    self.tool_executor.analyze_file(file_path, enabled_tools)
                )
            
            # Limit concurrency
            semaphore = asyncio.Semaphore(self.config.MAX_CONCURRENT_FILES)
            
            async def bounded_analyze(task):
                async with semaphore:
                    return await task
            
            results = await asyncio.gather(
                *[bounded_analyze(task) for task in tasks],
                return_exceptions=True
            )
            
            # Collect findings by file
            for file_path, result in zip(state.files_to_analyze, results):
                if isinstance(result, dict):
                    # Normalize findings
                    normalized = self.finding_normalizer.normalize_all_findings(result)
                    state.static_findings[str(file_path)] = normalized
    
    async def _stage_agent_analysis(self, state: WorkflowState):
        """Stage 4: Run multi-agent analysis"""
        with self.metrics.measure_time("agent_analysis"):
            tasks = []
            
            # For each chunk, run all agents
            for chunk in state.chunks:
                # Get static findings for this chunk
                chunk_findings = state.static_findings.get(chunk.file_path, [])
                chunk_findings = [
                    f for f in chunk_findings
                    if f.line >= chunk.start_line and f.line <= chunk.end_line
                ]
                
                # Create agent input
                agent_input = AgentInput(
                    chunk=chunk,
                    static_findings=chunk_findings,
                    dependency_context={},
                    file_context=""
                )
                
                # Create task for each agent
                for agent_name, agent in self.agents.items():
                    tasks.append(agent.analyze(agent_input))
            
            # Execute with concurrency limit
            semaphore = asyncio.Semaphore(self.config.MAX_CONCURRENT_AGENTS)
            
            async def bounded_analyze(task):
                async with semaphore:
                    return await task
            
            results = await asyncio.gather(
                *[bounded_analyze(task) for task in tasks],
                return_exceptions=True
            )
            
            # Collect outputs
            for result in results:
                if not isinstance(result, Exception):
                    state.agent_outputs.append(result)
                    state.total_cost += result.cost
                else:
                    logger.warning(f"Agent failed: {result}")
            
            self.metrics.increment_counter("agent_calls", len(results))
    
    async def _stage_verification(self, state: WorkflowState):
        """Stage 5: Verify all findings"""
        with self.metrics.measure_time("verification"):
            # Group agent outputs by chunk
            outputs_by_chunk = {}
            for output in state.agent_outputs:
                for issue in output.issues:
                    chunk_id = issue.id.split(':')[0]
                    if chunk_id not in outputs_by_chunk:
                        outputs_by_chunk[chunk_id] = []
                    outputs_by_chunk[chunk_id].append(output)
            
            # Verify each chunk's findings
            verified = []
            for chunk_id, outputs in outputs_by_chunk.items():
                # Find the chunk
                chunk = next((c for c in state.chunks if c.chunk_id == chunk_id), None)
                if not chunk:
                    continue
                
                # Get static findings for this chunk
                chunk_findings = state.static_findings.get(chunk.file_path, [])
                
                # Verify
                verified_issues = await self.verifier.verify_issues(
                    outputs,
                    chunk_findings,
                    chunk
                )
                verified.extend(verified_issues)
            
            state.verified_issues = verified
            self.metrics.increment_counter("verified_issues", len(verified))
    
    async def _stage_aggregation(self, state: WorkflowState):
        """Stage 6: Aggregate findings hierarchically"""
        with self.metrics.measure_time("aggregation"):
            # Group chunks by file
            chunks_by_file = {}
            for chunk in state.chunks:
                if chunk.file_path not in chunks_by_file:
                    chunks_by_file[chunk.file_path] = []
                chunks_by_file[chunk.file_path].append(chunk)
            
            # Aggregate chunk -> file level
            file_analyses = []
            for file_path, file_chunks in chunks_by_file.items():
                # Get chunk analyses
                chunk_analyses = []
                for chunk in file_chunks:
                    # Get agent outputs for this chunk
                    chunk_outputs = [
                        o for o in state.agent_outputs
                        if any(i.id.startswith(chunk.chunk_id) for i in o.issues)
                    ]
                    
                    if chunk_outputs:
                        chunk_analysis = self.chunk_aggregator.aggregate_chunk_issues(
                            chunk_outputs,
                            chunk
                        )
                        chunk_analyses.append(chunk_analysis)
                
                if chunk_analyses:
                    # Aggregate to file level
                    language = self.language_detector.detect(Path(file_path))
                    file_analysis = self.file_aggregator.aggregate_file_issues(
                        chunk_analyses,
                        file_path,
                        language or "unknown"
                    )
                    file_analyses.append(file_analysis)
            
            state.file_analyses = file_analyses
            
            # Detect module-level issues
            if state.dependency_graph:
                module_issues = self.module_aggregator.aggregate_module_issues(
                    file_analyses,
                    state.dependency_graph
                )
                # Add module issues to file analyses
                # (simplified - would need proper integration)
    
    async def _stage_finalization(self, state: WorkflowState) -> RepositoryAnalysis:
        """Stage 7: Generate final analysis result"""
        with self.metrics.measure_time("finalization"):
            # Aggregate to repository level
            result = self.system_aggregator.aggregate_to_repository_level(
                state.file_analyses
            )
            
            # Add metadata
            result.repository_name = Path(state.source_location).name
            result.analysis_id = state.analysis_id
            result.processing_time_seconds = time.time() - state.processing_start_time
            result.total_cost = state.total_cost
            result.languages_detected = list(state.languages_detected.keys())
            
            # Add metrics
            logger.info(f"Metrics: {self.metrics.get_summary()}")
            
            return result