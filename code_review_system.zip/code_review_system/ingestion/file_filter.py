import fnmatch
from pathlib import Path
from typing import List, Set


class FileFilter:
    """Filter files based on patterns and rules"""
    
    def __init__(self, ignore_patterns: List[str]):
        self.ignore_patterns = ignore_patterns
    
    def should_ignore(self, file_path: Path, repo_root: Path) -> bool:
        """
        Check if file should be ignored.
        
        Args:
            file_path: Path to file
            repo_root: Repository root path
            
        Returns:
            True if file should be ignored
        """
        relative_path = file_path.relative_to(repo_root)
        path_str = str(relative_path)
        
        for pattern in self.ignore_patterns:
            if fnmatch.fnmatch(path_str, pattern):
                return True
            
            # Check each path component
            for part in relative_path.parts:
                if fnmatch.fnmatch(part, pattern):
                    return True
        
        return False
    
    def filter_files(
        self,
        repo_path: Path,
        supported_languages: Set[str],
        language_detector: 'LanguageDetector'
    ) -> List[Path]:
        """
        Get all files that should be analyzed.
        
        Args:
            repo_path: Path to repository
            supported_languages: Set of supported language names
            language_detector: Language detector instance
            
        Returns:
            List of file paths to analyze
        """
        files_to_analyze = []
        
        for file_path in repo_path.rglob('*'):
            if not file_path.is_file():
                continue
            
            # Check if ignored
            if self.should_ignore(file_path, repo_path):
                continue
            
            # Check if supported language
            language = language_detector.detect(file_path)
            if language and language in supported_languages:
                files_to_analyze.append(file_path)
        
        return files_to_analyze