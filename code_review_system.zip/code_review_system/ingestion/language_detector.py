from pathlib import Path
from typing import Dict, Optional
import mimetypes


class LanguageDetector:
    """Detect programming language from file extension and content"""
    
    # Extension -> Language mapping
    EXTENSION_MAP = {
        '.py': 'python',
        '.java': 'java',
        '.js': 'javascript',
        '.ts': 'typescript',
        '.jsx': 'javascript',
        '.tsx': 'typescript',
        '.cpp': 'cpp',
        '.cc': 'cpp',
        '.cxx': 'cpp',
        '.c': 'c',
        '.h': 'c',
        '.hpp': 'cpp',
        '.go': 'go',
        '.rs': 'rust',
        '.rb': 'ruby',
        '.php': 'php',
        '.swift': 'swift',
        '.kt': 'kotlin',
        '.scala': 'scala',
    }
    
    def detect(self, file_path: Path) -> Optional[str]:
        """
        Detect language from file.
        
        Args:
            file_path: Path to file
            
        Returns:
            Language name or None if not supported
        """
        ext = file_path.suffix.lower()
        return self.EXTENSION_MAP.get(ext)
    
    def get_file_statistics(self, repo_path: Path) -> Dict[str, int]:
        """
        Get statistics of languages in repository.
        
        Args:
            repo_path: Path to repository
            
        Returns:
            Dictionary of language -> file count
        """
        stats = {}
        
        for file_path in repo_path.rglob('*'):
            if file_path.is_file():
                lang = self.detect(file_path)
                if lang:
                    stats[lang] = stats.get(lang, 0) + 1
        
        return stats

