import os
import tempfile
import zipfile
from pathlib import Path
from typing import List, Optional
import git
from abc import ABC, abstractmethod


class RepositoryLoader(ABC):
    """Abstract base for different source loaders"""
    
    @abstractmethod
    async def load(self, source: str) -> Path:
        """Load source and return local path"""
        pass


class GitRepositoryLoader(RepositoryLoader):
    """Load code from Git repositories"""
    
    async def load(self, source: str, branch: str = "main") -> Path:
        """
        Clone repository to temporary directory.
        
        Args:
            source: Git URL or local path
            branch: Branch to checkout
            
        Returns:
            Path to cloned repository
        """
        temp_dir = tempfile.mkdtemp(prefix="code_review_")
        
        try:
            if os.path.isdir(source):
                # Local repository
                repo = git.Repo(source)
                return Path(source)
            else:
                # Remote repository
                repo = git.Repo.clone_from(
                    source,
                    temp_dir,
                    branch=branch,
                    depth=1  # Shallow clone for efficiency
                )
                return Path(temp_dir)
        except Exception as e:
            raise RuntimeError(f"Failed to load Git repository: {e}")


class ZipRepositoryLoader(RepositoryLoader):
    """Load code from ZIP archives"""
    
    async def load(self, source: str) -> Path:
        """
        Extract ZIP archive to temporary directory.
        
        Args:
            source: Path to ZIP file
            
        Returns:
            Path to extracted contents
        """
        temp_dir = tempfile.mkdtemp(prefix="code_review_")
        
        try:
            with zipfile.ZipFile(source, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            return Path(temp_dir)
        except Exception as e:
            raise RuntimeError(f"Failed to extract ZIP archive: {e}")


class PullRequestLoader(RepositoryLoader):
    """Load code from GitHub Pull Request"""
    
    async def load(self, pr_url: str) -> tuple[Path, List[str]]:
        """
        Clone repository and get changed files from PR.
        
        Args:
            pr_url: GitHub PR URL
            
        Returns:
            Tuple of (repo_path, changed_files)
        """
        # Parse PR URL to get repo and PR number
        # Example: https://github.com/owner/repo/pull/123
        parts = pr_url.rstrip('/').split('/')
        owner, repo_name, pr_number = parts[-4], parts[-3], parts[-1]
        
        repo_url = f"https://github.com/{owner}/{repo_name}.git"
        
        temp_dir = tempfile.mkdtemp(prefix="code_review_pr_")
        repo = git.Repo.clone_from(repo_url, temp_dir)
        
        # Get changed files in PR (would use GitHub API in production)
        # For now, return repo path
        return Path(temp_dir), []


class LoaderFactory:
    """Factory for creating appropriate loader"""
    
    @staticmethod
    def create_loader(source_type: str) -> RepositoryLoader:
        loaders = {
            "git": GitRepositoryLoader(),
            "zip": ZipRepositoryLoader(),
            "pr": PullRequestLoader(),
        }
        
        if source_type not in loaders:
            raise ValueError(f"Unsupported source type: {source_type}")
        
        return loaders[source_type]
