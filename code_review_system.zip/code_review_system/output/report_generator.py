from pathlib import Path
from typing import Optional


class ReportGenerator:
    """
    Generate various report formats (HTML, PDF, Markdown).
    """
    
    def generate_html_report(
        self,
        analysis: 'RepositoryAnalysis',
        output_path: Optional[Path] = None
    ) -> str:
        """Generate HTML report"""
        
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Code Review Report - {analysis.repository_name}</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .metric {{
            display: inline-block;
            background: white;
            padding: 20px;
            margin: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .metric-value {{
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }}
        .metric-label {{
            color: #666;
            font-size: 14px;
        }}
        .issue {{
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }}
        .critical {{ border-left-color: #e53e3e; }}
        .high {{ border-left-color: #ed8936; }}
        .medium {{ border-left-color: #ecc94b; }}
        .low {{ border-left-color: #48bb78; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Code Review Analysis Report</h1>
        <p>{analysis.repository_name}</p>
        <p>Analysis ID: {analysis.analysis_id}</p>
    </div>
    
    <div class="metrics">
        <div class="metric">
            <div class="metric-value">{analysis.files_analyzed}</div>
            <div class="metric-label">Files Analyzed</div>
        </div>
        <div class="metric">
            <div class="metric-value">{analysis.total_issues}</div>
            <div class="metric-label">Total Issues</div>
        </div>
        <div class="metric">
            <div class="metric-value">{analysis.overall_risk_score:.0f}/100</div>
            <div class="metric-label">Risk Score</div>
        </div>
        <div class="metric">
            <div class="metric-value">${analysis.total_cost:.2f}</div>
            <div class="metric-label">Analysis Cost</div>
        </div>
    </div>
    
    <h2>Issues by Severity</h2>
"""
        
        # Group issues by severity
        all_issues = []
        for file_analysis in analysis.file_analyses:
            all_issues.extend(file_analysis.aggregated_issues)
        
        for severity in ["critical", "high", "medium", "low"]:
            severity_issues = [i for i in all_issues if i.severity.value == severity]
            
            if severity_issues:
                html += f"<h3>{severity.title()} ({len(severity_issues)})</h3>"
                
                for issue in severity_issues[:10]:  # Limit to 10 per severity
                    html += f"""
                    <div class="issue {severity}">
                        <h4>{issue.title}</h4>
                        <p>{issue.description}</p>
                        <p><strong>Location:</strong> {issue.location.file_path}:{issue.location.start_line}</p>
                        <p><strong>Confidence:</strong> {issue.confidence * 100:.0f}%</p>
                    </div>
                    """
        
        html += """
</body>
</html>
"""
        
        if output_path:
            output_path.write_text(html)
        
        return html
    
    def generate_markdown_report(
        self,
        analysis: 'RepositoryAnalysis',
        output_path: Optional[Path] = None
    ) -> str:
        """Generate Markdown report"""
        
        md = f"""# Code Review Analysis Report

**Repository:** {analysis.repository_name}
**Analysis ID:** {analysis.analysis_id}
**Date:** {analysis.timestamp}

## Summary

| Metric | Value |
|--------|-------|
| Files Analyzed | {analysis.files_analyzed} |
| Lines of Code | {analysis.lines_analyzed:,} |
| Total Issues | {analysis.total_issues} |
| Risk Score | {analysis.overall_risk_score:.1f}/100 |
| Processing Time | {analysis.processing_time_seconds:.1f}s |
| Cost | ${analysis.total_cost:.2f} |

## Issues by Severity

- 🔴 Critical: {analysis.critical_issues}
- 🟠 High: {analysis.high_issues}
- 🟡 Medium: {analysis.medium_issues}
- 🟢 Low: {analysis.low_issues}

## Top Issues

"""
        
        all_issues = []
        for file_analysis in analysis.file_analyses:
            all_issues.extend(file_analysis.aggregated_issues)
        
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        top_issues = sorted(
            all_issues,
            key=lambda i: (severity_order.get(i.severity.value, 5), -i.confidence)
        )[:20]
        
        for i, issue in enumerate(top_issues, 1):
            emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}.get(
                issue.severity.value, "⚪"
            )
            
            md += f"""
### {i}. {emoji} {issue.title}

**Severity:** {issue.severity.value.upper()}
**File:** `{issue.location.file_path}:{issue.location.start_line}`
**Confidence:** {issue.confidence * 100:.0f}%

{issue.description}

"""
            
            if issue.suggested_fix:
                md += f"**Suggested Fix:**\n{issue.suggested_fix}\n\n"
        
        if output_path:
            output_path.write_text(md)
        
        return md
