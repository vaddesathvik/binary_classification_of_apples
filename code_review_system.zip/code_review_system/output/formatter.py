import json
from typing import Dict, Any
from datetime import datetime


class OutputFormatter:
    """
    Format analysis results into various output formats.
    """
    
    def format_json(self, analysis: 'RepositoryAnalysis') -> str:
        """Format as JSON"""
        return json.dumps(
            self._to_serializable_dict(analysis),
            indent=2
        )
    
    def format_summary(self, analysis: 'RepositoryAnalysis') -> str:
        """Format as human-readable summary"""
        lines = []
        lines.append("=" * 70)
        lines.append("CODE REVIEW ANALYSIS REPORT")
        lines.append("=" * 70)
        lines.append(f"Repository: {analysis.repository_name}")
        lines.append(f"Analysis ID: {analysis.analysis_id}")
        lines.append(f"Timestamp: {analysis.timestamp}")
        lines.append("")
        
        lines.append("SUMMARY")
        lines.append("-" * 70)
        lines.append(f"Files Analyzed: {analysis.files_analyzed}")
        lines.append(f"Lines of Code: {analysis.lines_analyzed:,}")
        lines.append(f"Languages: {', '.join(analysis.languages_detected)}")
        lines.append("")
        
        lines.append("ISSUES FOUND")
        lines.append("-" * 70)
        lines.append(f"Total Issues: {analysis.total_issues}")
        lines.append(f"  Critical: {analysis.critical_issues}")
        lines.append(f"  High:     {analysis.high_issues}")
        lines.append(f"  Medium:   {analysis.medium_issues}")
        lines.append(f"  Low:      {analysis.low_issues}")
        lines.append("")
        
        lines.append("RISK ASSESSMENT")
        lines.append("-" * 70)
        lines.append(f"Overall Risk Score: {analysis.overall_risk_score:.1f}/100")
        lines.append(f"Confidence Level: {analysis.confidence * 100:.1f}%")
        lines.append("")
        
        lines.append("PERFORMANCE")
        lines.append("-" * 70)
        lines.append(f"Processing Time: {analysis.processing_time_seconds:.1f}s")
        lines.append(f"Total Cost: ${analysis.total_cost:.2f}")
        lines.append("")
        
        # Top issues
        lines.append("TOP ISSUES")
        lines.append("-" * 70)
        
        all_issues = []
        for file_analysis in analysis.file_analyses:
            all_issues.extend(file_analysis.aggregated_issues)
        
        # Sort by severity and confidence
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        top_issues = sorted(
            all_issues,
            key=lambda i: (severity_order.get(i.severity.value, 5), -i.confidence)
        )[:10]
        
        for i, issue in enumerate(top_issues, 1):
            lines.append(f"{i}. [{issue.severity.value.upper()}] {issue.title}")
            lines.append(f"   File: {issue.location.file_path}:{issue.location.start_line}")
            lines.append(f"   Confidence: {issue.confidence * 100:.0f}%")
            lines.append("")
        
        lines.append("=" * 70)
        
        return "\n".join(lines)
    
    def _to_serializable_dict(self, obj: Any) -> Dict:
        """Convert Pydantic model to serializable dict"""
        if hasattr(obj, 'dict'):
            data = obj.dict()
        else:
            data = obj
        
        # Convert datetime objects
        for key, value in data.items():
            if isinstance(value, datetime):
                data[key] = value.isoformat()
        
        return data
