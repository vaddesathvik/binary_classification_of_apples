import asyncio
from typing import List, Callable, Any, TypeVar
from functools import wraps

T = TypeVar('T')


async def gather_with_limit(
    tasks: List[Callable],
    limit: int = 10
) -> List[Any]:
    """
    Execute async tasks with concurrency limit.
    
    Args:
        tasks: List of coroutines to execute
        limit: Maximum concurrent tasks
        
    Returns:
        List of results
    """
    semaphore = asyncio.Semaphore(limit)
    
    async def bounded_task(task):
        async with semaphore:
            return await task
    
    return await asyncio.gather(
        *[bounded_task(task) for task in tasks],
        return_exceptions=True
    )


def async_retry(max_attempts: int = 3, delay: float = 1.0):
    """
    Decorator for retrying async functions.
    
    Args:
        max_attempts: Maximum retry attempts
        delay: Delay between retries in seconds
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        await asyncio.sleep(delay * (attempt + 1))
                    else:
                        raise last_exception
        
        return wrapper
    return decorator

