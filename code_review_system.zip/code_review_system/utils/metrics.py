import time
from contextlib import contextmanager
from typing import Dict, List
import psutil


class MetricsCollector:
    """
    Collect performance and usage metrics.
    """
    
    def __init__(self):
        self.timings: Dict[str, List[float]] = {}
        self.counters: Dict[str, int] = {}
        self.memory_usage: List[float] = []
    
    @contextmanager
    def measure_time(self, operation: str):
        """Context manager to measure operation time"""
        start = time.time()
        try:
            yield
        finally:
            elapsed = time.time() - start
            if operation not in self.timings:
                self.timings[operation] = []
            self.timings[operation].append(elapsed)
    
    def increment_counter(self, counter: str, value: int = 1):
        """Increment a counter"""
        if counter not in self.counters:
            self.counters[counter] = 0
        self.counters[counter] += value
    
    def record_memory(self):
        """Record current memory usage"""
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        self.memory_usage.append(memory_mb)
    
    def get_summary(self) -> Dict:
        """Get metrics summary"""
        summary = {
            "timings": {},
            "counters": self.counters,
            "memory": {
                "peak_mb": max(self.memory_usage) if self.memory_usage else 0,
                "avg_mb": sum(self.memory_usage) / len(self.memory_usage) 
                         if self.memory_usage else 0
            }
        }
        
        for operation, times in self.timings.items():
            summary["timings"][operation] = {
                "count": len(times),
                "total_seconds": sum(times),
                "avg_seconds": sum(times) / len(times),
                "min_seconds": min(times),
                "max_seconds": max(times)
            }
        
        return summary
