from fastapi import FastAPI, HTTPException, BackgroundTasks, UploadFile, File
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uuid
import asyncio
from typing import Optional

app = FastAPI(
    title="Enterprise Code Review API",
    description="AI-Powered Code Review for Large-Scale Codebases",
    version="1.0.0"
)

# Global state
active_analyses = {}
settings = get_settings()


class AnalysisResponse(BaseModel):
    """API response for analysis request"""
    analysis_id: str
    status: str
    message: str


@app.post("/api/v1/analyze", response_model=AnalysisResponse)
async def analyze_repository(
    request: AnalysisRequest,
    background_tasks: BackgroundTasks
) -> AnalysisResponse:
    """
    Start code analysis.
    
    This is an async endpoint that immediately returns an analysis ID.
    The actual analysis runs in the background.
    """
    
    analysis_id = str(uuid.uuid4())
    
    active_analyses[analysis_id] = {
        "status": "queued",
        "progress": 0,
        "result": None
    }
    
    # Run analysis in background
    background_tasks.add_task(
        run_analysis,
        analysis_id,
        request
    )
    
    return AnalysisResponse(
        analysis_id=analysis_id,
        status="queued",
        message=f"Analysis {analysis_id} queued successfully"
    )


@app.get("/api/v1/analysis/{analysis_id}")
async def get_analysis_status(analysis_id: str):
    """Get status of running analysis"""
    
    if analysis_id not in active_analyses:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    return active_analyses[analysis_id]


@app.get("/api/v1/analysis/{analysis_id}/report")
async def get_analysis_report(analysis_id: str):
    """Get full analysis report"""
    
    if analysis_id not in active_analyses:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    analysis = active_analyses[analysis_id]
    
    if analysis["status"] != "completed":
        raise HTTPException(
            status_code=400,
            detail=f"Analysis not complete. Status: {analysis['status']}"
        )
    
    return analysis["result"]


@app.post("/api/v1/analyze/upload")
async def analyze_uploaded_code(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = None
):
    """
    Analyze uploaded ZIP file.
    
    Useful for analyzing codebases without Git access.
    """
    
    import tempfile
    import shutil
    
    # Save uploaded file
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    shutil.copyfileobj(file.file, temp_file)
    temp_file.close()
    
    # Create analysis request
    request = AnalysisRequest(
        source_type="zip",
        source_location=temp_file.name
    )
    
    return await analyze_repository(request, background_tasks)


async def run_analysis(analysis_id: str, request: AnalysisRequest):
    """Background task to run full analysis"""
    
    try:
        active_analyses[analysis_id]["status"] = "running"
        
        # Initialize workflow
        workflow = CodeReviewWorkflow(settings)
        
        # Execute analysis
        result = await workflow.execute(request)
        
        # Store result
        active_analyses[analysis_id] = {
            "status": "completed",
            "progress": 100,
            "result": result.dict()
        }
        
    except Exception as e:
        active_analyses[analysis_id] = {
            "status": "failed",
            "progress": 0,
            "error": str(e)
        }


@app.get("/api/v1/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "active_analyses": len(active_analyses)
    }


@app.get("/api/v1/metrics")
async def get_metrics():
    """Get system metrics"""
    
    # Would integrate with Prometheus/Grafana in production
    return {
        "total_analyses": len(active_analyses),
        "running_analyses": sum(
            1 for a in active_analyses.values()
            if a["status"] == "running"
        ),
        "completed_analyses": sum(
            1 for a in active_analyses.values()
            if a["status"] == "completed"
        )
    }


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        workers=settings.API_WORKERS,
        log_level="info"
    )
