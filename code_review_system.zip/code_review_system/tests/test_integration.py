# tests/test_integration.py
"""
End-to-end integration tests for complete workflow.
Tests the entire system from code ingestion to final report.
"""

import pytest
import tempfile
import shutil
from pathlib import Path
from orchestration.workflow import CodeReviewWorkflow
from models.schemas import AnalysisRequest, Severity
from config.settings import Settings


@pytest.mark.integration
class TestEndToEndWorkflow:
    """Integration tests for complete code review workflow"""
    
    @pytest.fixture
    def workflow(self):
        """Create workflow with test settings"""
        settings = Settings()
        # Override with test values
        settings.MIN_CONFIDENCE_THRESHOLD = 0.5  # Lower for testing
        settings.MAX_CONCURRENT_AGENTS = 2  # Limit for tests
        return CodeReviewWorkflow(settings)
    
    @pytest.fixture
    def simple_repository(self, tmp_path):
        """Create a simple test repository"""
        repo_path = tmp_path / "test_repo"
        repo_path.mkdir()
        
        # Create simple Python file
        (repo_path / "app.py").write_text("""
def add(a, b):
    '''Add two numbers'''
    return a + b

def greet(name):
    '''Greet someone'''
    return f"Hello, {name}!"
""")
        
        return repo_path
    
    @pytest.fixture
    def repository_with_issues(self, tmp_path):
        """Create repository with known issues"""
        repo_path = tmp_path / "test_repo"
        repo_path.mkdir()
        
        # File with security issues
        (repo_path / "security_issues.py").write_text("""
import os
import pickle

def unsafe_function(user_input):
    # SQL injection
    query = f"SELECT * FROM users WHERE name = '{user_input}'"
    
    # Command injection
    os.system(f"ls {user_input}")
    
    # Unsafe deserialization
    data = pickle.loads(user_input)
    
    return query
""")
        
        # File with performance issues
        (repo_path / "performance_issues.py").write_text("""
def slow_function(data):
    '''O(n²) complexity'''
    result = []
    for i in range(len(data)):
        for j in range(len(data)):
            if i != j and data[i] == data[j]:
                result.append(data[i])
    return result

def another_slow_function(items):
    '''Inefficient list operations'''
    for item in items:
        if item in result:  # O(n) lookup in list
            continue
        result.append(item)
    return result
""")
        
        # File with style issues
        (repo_path / "style_issues.py").write_text("""
def BadFunctionName(x):  # Should be snake_case
    CONSTANT = 42  # Should be module-level
    unused_variable = 10
    return x + CONSTANT

class myClass:  # Should be PascalCase
    def __init__(self):
        self.value = 1
""")
        
        return repo_path
    
    @pytest.mark.asyncio
    @pytest.mark.slow
    async def test_analyze_simple_repository(self, workflow, simple_repository):
        """Test analyzing a simple repository with no issues"""
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(simple_repository)
        )
        
        # Note: This would normally fail without actual LLM
        # In production, you'd mock the LLM calls or use test API
        try:
            result = await workflow.execute(request)
            
            # Verify basic structure
            assert result.files_analyzed > 0
            assert result.lines_analyzed > 0
            assert isinstance(result.total_issues, int)
            assert result.overall_risk_score >= 0
            assert result.processing_time_seconds > 0
            
        except Exception as e:
            # Expected if LLM APIs not available in test
            pytest.skip(f"LLM APIs not available: {e}")
    
    @pytest.mark.asyncio
    @pytest.mark.slow
    async def test_analyze_repository_with_issues(
        self,
        workflow,
        repository_with_issues
    ):
        """Test analyzing repository with known issues"""
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(repository_with_issues)
        )
        
        try:
            result = await workflow.execute(request)
            
            # Should find issues
            assert result.total_issues > 0
            
            # Should have multiple files
            assert result.files_analyzed == 3
            
            # Should categorize by severity
            assert result.critical_issues >= 0
            assert result.high_issues >= 0
            assert result.medium_issues >= 0
            assert result.low_issues >= 0
            
            # Total should match sum
            total = (
                result.critical_issues +
                result.high_issues +
                result.medium_issues +
                result.low_issues
            )
            assert total == result.total_issues
            
        except Exception as e:
            pytest.skip(f"LLM APIs not available: {e}")
    
    @pytest.mark.asyncio
    async def test_workflow_stages_execute_in_order(
        self,
        workflow,
        simple_repository
    ):
        """Test that workflow stages execute in correct order"""
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(simple_repository)
        )
        
        # Track stages
        stages_executed = []
        
        original_stage_ingestion = workflow._stage_ingestion
        original_stage_chunking = workflow._stage_chunking
        
        async def tracked_ingestion(state, req):
            stages_executed.append("ingestion")
            return await original_stage_ingestion(state, req)
        
        async def tracked_chunking(state):
            stages_executed.append("chunking")
            return await original_stage_chunking(state)
        
        workflow._stage_ingestion = tracked_ingestion
        workflow._stage_chunking = tracked_chunking
        
        try:
            await workflow.execute(request)
            
            # Verify order
            assert stages_executed[0] == "ingestion"
            assert stages_executed[1] == "chunking"
            
        except Exception as e:
            # May fail if LLM not available, but we can still check order
            if len(stages_executed) >= 2:
                assert stages_executed[0] == "ingestion"
                assert stages_executed[1] == "chunking"
    
    @pytest.mark.asyncio
    async def test_workflow_handles_empty_repository(self, workflow, tmp_path):
        """Test handling of empty repository"""
        empty_repo = tmp_path / "empty_repo"
        empty_repo.mkdir()
        
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(empty_repo)
        )
        
        try:
            result = await workflow.execute(request)
            
            # Should complete without errors
            assert result.files_analyzed == 0
            assert result.total_issues == 0
            
        except Exception as e:
            # Should not crash
            pass
    
    @pytest.mark.asyncio
    async def test_workflow_filters_ignored_files(self, workflow, tmp_path):
        """Test that ignored files are filtered out"""
        repo = tmp_path / "repo"
        repo.mkdir()
        
        # Create files that should be analyzed
        (repo / "app.py").write_text("def main(): pass")
        
        # Create files that should be ignored
        (repo / "test.pyc").write_text("compiled")
        pycache = repo / "__pycache__"
        pycache.mkdir()
        (pycache / "app.cpython-39.pyc").write_text("compiled")
        
        node_modules = repo / "node_modules"
        node_modules.mkdir()
        (node_modules / "package.js").write_text("// js")
        
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(repo)
        )
        
        try:
            result = await workflow.execute(request)
            
            # Should only analyze Python files, not ignored ones
            assert result.files_analyzed == 1
            
        except Exception as e:
            pytest.skip(f"LLM APIs not available: {e}")
    
    @pytest.mark.asyncio
    async def test_workflow_calculates_risk_score(
        self,
        workflow,
        repository_with_issues
    ):
        """Test risk score calculation"""
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(repository_with_issues)
        )
        
        try:
            result = await workflow.execute(request)
            
            # Risk score should be between 0 and 100
            assert 0 <= result.overall_risk_score <= 100
            
            # Repository with critical issues should have high risk
            if result.critical_issues > 0:
                assert result.overall_risk_score > 20
            
        except Exception as e:
            pytest.skip(f"LLM APIs not available: {e}")
    
    @pytest.mark.asyncio
    async def test_workflow_tracks_cost(self, workflow, simple_repository):
        """Test that API costs are tracked"""
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(simple_repository)
        )
        
        try:
            result = await workflow.execute(request)
            
            # Should track costs
            assert isinstance(result.total_cost, float)
            assert result.total_cost >= 0
            
        except Exception as e:
            pytest.skip(f"LLM APIs not available: {e}")
    
    @pytest.mark.asyncio
    async def test_workflow_tracks_processing_time(
        self,
        workflow,
        simple_repository
    ):
        """Test that processing time is recorded"""
        request = AnalysisRequest(
            source_type="folder",
            source_location=str(simple_repository)
        )
        
        try:
            result = await workflow.execute(request)
            
            # Should have positive processing time
            assert result.processing_time_seconds > 0
            
        except Exception as e:
            pytest.skip(f"LLM APIs not available: {e}")


@pytest.mark.integration
class TestFileIngestion:
    """Test different ingestion methods"""
    
    @pytest.mark.asyncio
    async def test_ingest_from_folder(self, tmp_path):
        """Test ingesting code from folder"""
        from ingestion.repository_loader import LoaderFactory
        
        # Create test folder
        folder = tmp_path / "code"
        folder.mkdir()
        (folder / "main.py").write_text("def main(): pass")
        
        loader = LoaderFactory.create_loader("folder")
        # Note: folder type would need implementation
        # This is a placeholder for the pattern
    
    @pytest.mark.asyncio
    async def test_ingest_from_zip(self, tmp_path):
        """Test ingesting code from ZIP file"""
        from ingestion.repository_loader import ZipRepositoryLoader
        import zipfile
        
        # Create test files
        code_dir = tmp_path / "code"
        code_dir.mkdir()
        (code_dir / "app.py").write_text("def app(): pass")
        
        # Create ZIP
        zip_path = tmp_path / "code.zip"
        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.write(code_dir / "app.py", "app.py")
        
        # Load from ZIP
        loader = ZipRepositoryLoader()
        extracted_path = await loader.load(str(zip_path))
        
        # Verify extraction
        assert extracted_path.exists()
        assert (extracted_path / "app.py").exists()


@pytest.mark.integration
class TestOutputGeneration:
    """Test output formatting and reporting"""
    
    @pytest.fixture
    def sample_analysis_result(self):
        """Create sample analysis result"""
        from models.schemas import RepositoryAnalysis, FileAnalysis
        from datetime import datetime
        import uuid
        
        return RepositoryAnalysis(
            repository_name="test_repo",
            analysis_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow(),
            file_analyses=[],
            total_issues=10,
            critical_issues=2,
            high_issues=3,
            medium_issues=3,
            low_issues=2,
            overall_risk_score=45.5,
            confidence=0.85,
            total_cost=1.25,
            processing_time_seconds=30.5,
            languages_detected=["python"],
            files_analyzed=5,
            lines_analyzed=1250
        )
    
    def test_json_output_format(self, sample_analysis_result):
        """Test JSON output formatting"""
        from output.formatter import OutputFormatter
        
        formatter = OutputFormatter()
        json_output = formatter.format_json(sample_analysis_result)
        
        # Should be valid JSON
        import json
        parsed = json.loads(json_output)
        
        # Verify structure
        assert parsed["repository_name"] == "test_repo"
        assert parsed["total_issues"] == 10
        assert parsed["overall_risk_score"] == 45.5
    
    def test_summary_output_format(self, sample_analysis_result):
        """Test summary text format"""
        from output.formatter import OutputFormatter
        
        formatter = OutputFormatter()
        summary = formatter.format_summary(sample_analysis_result)
        
        # Should contain key information
        assert "test_repo" in summary
        assert "10" in summary  # total issues
        assert "45.5" in summary  # risk score
        assert "CODE REVIEW ANALYSIS REPORT" in summary
    
    def test_html_report_generation(self, sample_analysis_result, tmp_path):
        """Test HTML report generation"""
        from output.report_generator import ReportGenerator
        
        generator = ReportGenerator()
        output_path = tmp_path / "report.html"
        
        html = generator.generate_html_report(
            sample_analysis_result,
            output_path
        )
        
        # Should create valid HTML
        assert "<html>" in html.lower()
        assert "test_repo" in html
        assert output_path.exists()
    
    def test_markdown_report_generation(self, sample_analysis_result, tmp_path):
        """Test Markdown report generation"""
        from output.report_generator import ReportGenerator
        
        generator = ReportGenerator()
        output_path = tmp_path / "report.md"
        
        markdown = generator.generate_markdown_report(
            sample_analysis_result,
            output_path
        )
        
        # Should contain markdown elements
        assert "#" in markdown  # Headers
        assert "test_repo" in markdown
        assert output_path.exists()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-m", "integration"])