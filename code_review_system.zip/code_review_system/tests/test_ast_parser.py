"""
Comprehensive tests for AST-based code chunking.
Tests the critical ability to handle large files by semantic chunking.
"""

import pytest
from pathlib import Path
from chunking.ast_parser import ASTParser, CodeChunk
import tempfile


class TestASTParser:
    """Test AST-based code chunking"""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance"""
        return ASTParser()
    
    @pytest.fixture
    def sample_python_file(self, tmp_path):
        """Create a comprehensive Python file for testing"""
        file_path = tmp_path / "test_module.py"
        file_path.write_text("""
import os
import sys
from typing import List, Dict

# Module-level constant
MAX_RETRIES = 3

def simple_function():
    '''A simple function'''
    return "hello"

def function_with_args(a: int, b: str) -> str:
    '''Function with type hints'''
    return f"{a}: {b}"

class SimpleClass:
    '''A simple class'''
    
    def __init__(self):
        self.value = 42
    
    def method(self):
        if self.value > 0:
            return "positive"
        return "negative"

class ComplexClass:
    '''A more complex class with multiple methods'''
    
    CLASS_CONSTANT = "test"
    
    def __init__(self, name: str):
        self.name = name
        self._private = []
    
    def public_method(self) -> str:
        return self.name
    
    def _private_method(self):
        return self._private
    
    @property
    def computed_property(self):
        return len(self.name)
    
    @staticmethod
    def static_method():
        return "static"
    
    @classmethod
    def class_method(cls):
        return cls.CLASS_CONSTANT

def complex_function(data: List[int]) -> Dict[str, int]:
    '''Function with complex logic'''
    result = {}
    
    for i, item in enumerate(data):
        if item % 2 == 0:
            result[f'even_{i}'] = item
        else:
            result[f'odd_{i}'] = item
    
    return result

async def async_function():
    '''Async function'''
    return "async result"

def generator_function():
    '''Generator function'''
    for i in range(10):
        yield i

def nested_function():
    '''Function with nested function'''
    def inner():
        return "inner"
    return inner()
""")
        return file_path
    
    def test_parse_all_functions(self, parser, sample_python_file):
        """Test that all functions are identified"""
        chunks = parser.parse_python_file(sample_python_file)
        
        function_chunks = [c for c in chunks if c.chunk_type == "function"]
        function_names = [c.name for c in function_chunks]
        
        assert "simple_function" in function_names
        assert "function_with_args" in function_names
        assert "complex_function" in function_names
        assert "async_function" in function_names
        assert "generator_function" in function_names
        assert "nested_function" in function_names
        
        # Should have at least 6 functions
        assert len(function_chunks) >= 6
    
    def test_parse_all_classes(self, parser, sample_python_file):
        """Test that all classes are identified"""
        chunks = parser.parse_python_file(sample_python_file)
        
        class_chunks = [c for c in chunks if c.chunk_type == "class"]
        class_names = [c.name for c in class_chunks]
        
        assert "SimpleClass" in class_names
        assert "ComplexClass" in class_names
        assert len(class_chunks) == 2
    
    def test_chunk_metadata(self, parser, sample_python_file):
        """Test that chunks have correct metadata"""
        chunks = parser.parse_python_file(sample_python_file)
        
        for chunk in chunks:
            # All chunks should have required fields
            assert chunk.chunk_id
            assert chunk.file_path == str(sample_python_file)
            assert chunk.start_line > 0
            assert chunk.end_line >= chunk.start_line
            assert chunk.chunk_type in ["function", "class", "module"]
            assert chunk.name
            assert chunk.content
            assert isinstance(chunk.complexity, int)
            assert isinstance(chunk.dependencies, list)
    
    def test_complexity_calculation(self, parser, sample_python_file):
        """Test cyclomatic complexity calculation"""
        chunks = parser.parse_python_file(sample_python_file)
        
        # Find complex_function
        complex_chunk = next(
            (c for c in chunks if c.name == "complex_function"),
            None
        )
        assert complex_chunk is not None
        
        # Should have higher complexity due to loop and conditionals
        assert complex_chunk.complexity > 3
        
        # Simple function should have low complexity
        simple_chunk = next(
            (c for c in chunks if c.name == "simple_function"),
            None
        )
        assert simple_chunk is not None
        assert simple_chunk.complexity == 1
    
    def test_dependency_extraction(self, parser, sample_python_file):
        """Test that dependencies are extracted"""
        chunks = parser.parse_python_file(sample_python_file)
        
        # Complex function should have dependencies
        complex_chunk = next(
            (c for c in chunks if c.name == "complex_function"),
            None
        )
        assert complex_chunk is not None
        assert len(complex_chunk.dependencies) > 0
    
    def test_handles_syntax_errors(self, parser, tmp_path):
        """Test handling of files with syntax errors"""
        bad_file = tmp_path / "syntax_error.py"
        bad_file.write_text("""
def broken(:
    pass

class Incomplete
    def method(self):
        return
""")
        
        # Should not crash, return whole file as single chunk
        chunks = parser.parse_python_file(bad_file)
        assert len(chunks) == 1
        assert chunks[0].chunk_type == "module"
    
    def test_empty_file(self, parser, tmp_path):
        """Test handling of empty file"""
        empty_file = tmp_path / "empty.py"
        empty_file.write_text("")
        
        chunks = parser.parse_python_file(empty_file)
        assert len(chunks) == 1
        assert chunks[0].chunk_type == "module"
    
    def test_comments_only_file(self, parser, tmp_path):
        """Test handling of file with only comments"""
        comment_file = tmp_path / "comments.py"
        comment_file.write_text("""
# This is a comment
# Another comment

'''
Docstring
'''
""")
        
        chunks = parser.parse_python_file(comment_file)
        assert len(chunks) == 1
        assert chunks[0].chunk_type == "module"
    
    def test_large_file(self, parser, tmp_path):
        """Test handling of very large file (1000+ LOC)"""
        large_file = tmp_path / "large.py"
        
        # Generate 500 functions
        code = "\n".join([
            f"def function_{i}(x):\n    return x + {i}\n"
            for i in range(500)
        ])
        large_file.write_text(code)
        
        chunks = parser.parse_python_file(large_file)
        
        # Should create 500 function chunks
        assert len(chunks) == 500
        
        # Each should be a function
        assert all(c.chunk_type == "function" for c in chunks)
    
    def test_nested_classes(self, parser, tmp_path):
        """Test handling of nested classes"""
        nested_file = tmp_path / "nested.py"
        nested_file.write_text("""
class Outer:
    class Inner:
        def inner_method(self):
            pass
    
    def outer_method(self):
        pass
""")
        
        chunks = parser.parse_python_file(nested_file)
        
        # Should identify both classes
        class_chunks = [c for c in chunks if c.chunk_type == "class"]
        assert len(class_chunks) >= 1  # At least outer class
    
    def test_decorators(self, parser, tmp_path):
        """Test handling of decorated functions"""
        decorator_file = tmp_path / "decorators.py"
        decorator_file.write_text("""
def decorator(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@decorator
def decorated_function():
    return "decorated"

class MyClass:
    @staticmethod
    def static_method():
        return "static"
    
    @classmethod
    def class_method(cls):
        return "class"
    
    @property
    def prop(self):
        return "property"
""")
        
        chunks = parser.parse_python_file(decorator_file)
        
        # Should find decorated function
        decorated = next(
            (c for c in chunks if c.name == "decorated_function"),
            None
        )
        assert decorated is not None
    
    def test_async_functions(self, parser, tmp_path):
        """Test handling of async/await syntax"""
        async_file = tmp_path / "async_code.py"
        async_file.write_text("""
import asyncio

async def async_function():
    await asyncio.sleep(1)
    return "done"

async def another_async():
    result = await async_function()
    return result

class AsyncClass:
    async def async_method(self):
        return await self.helper()
    
    async def helper(self):
        return "helper"
""")
        
        chunks = parser.parse_python_file(async_file)
        
        # Should identify async functions
        async_funcs = [c for c in chunks if c.name in ["async_function", "another_async"]]
        assert len(async_funcs) == 2
    
    def test_chunk_content_accuracy(self, parser, sample_python_file):
        """Test that chunk content matches source code"""
        chunks = parser.parse_python_file(sample_python_file)
        
        # Read original file
        with open(sample_python_file, 'r') as f:
            original_lines = f.readlines()
        
        for chunk in chunks:
            # Extract expected content
            expected_content = ''.join(
                original_lines[chunk.start_line - 1:chunk.end_line]
            )
            
            # Chunk content should match (may have trailing whitespace differences)
            assert chunk.content.strip() == expected_content.strip()
    
    def test_chunk_ordering(self, parser, sample_python_file):
        """Test that chunks are in source order"""
        chunks = parser.parse_python_file(sample_python_file)
        
        # Filter to only functions/classes (not module)
        code_chunks = [c for c in chunks if c.chunk_type in ["function", "class"]]
        
        # Should be in ascending line order
        for i in range(len(code_chunks) - 1):
            assert code_chunks[i].start_line < code_chunks[i + 1].start_line
    
    def test_unicode_handling(self, parser, tmp_path):
        """Test handling of Unicode characters"""
        unicode_file = tmp_path / "unicode.py"
        unicode_file.write_text("""
def greet(name: str) -> str:
    '''Greet with emoji 👋'''
    return f"Hello {name} 🌍"

class 日本語:
    '''Class with Japanese name'''
    def método(self):
        '''Method with accent'''
        return "Olá"
""", encoding='utf-8')
        
        chunks = parser.parse_python_file(unicode_file)
        
        # Should handle Unicode without errors
        assert len(chunks) > 0
        
        # Check that Unicode is preserved
        greet_chunk = next((c for c in chunks if c.name == "greet"), None)
        assert greet_chunk is not None
        assert "👋" in greet_chunk.content or "🌍" in greet_chunk.content


class TestCodeChunkDataclass:
    """Test the CodeChunk dataclass"""
    
    def test_chunk_creation(self):
        """Test creating a CodeChunk"""
        chunk = CodeChunk(
            chunk_id="test:1",
            file_path="test.py",
            start_line=1,
            end_line=10,
            chunk_type="function",
            name="test_func",
            content="def test_func():\n    pass",
            complexity=1,
            dependencies=["os", "sys"]
        )
        
        assert chunk.chunk_id == "test:1"
        assert chunk.file_path == "test.py"
        assert chunk.start_line == 1
        assert chunk.end_line == 10
        assert chunk.chunk_type == "function"
        assert chunk.name == "test_func"
        assert chunk.complexity == 1
        assert len(chunk.dependencies) == 2
    
    def test_chunk_defaults(self):
        """Test CodeChunk default values"""
        chunk = CodeChunk(
            chunk_id="test:1",
            file_path="test.py",
            start_line=1,
            end_line=10,
            chunk_type="function",
            name="test_func",
            content="def test_func():\n    pass"
        )
        
        assert chunk.parent_chunk_id is None
        assert chunk.complexity == 0
        assert chunk.dependencies == []


if __name__ == "__main__":
    pytest.main([__file__, "-v"])