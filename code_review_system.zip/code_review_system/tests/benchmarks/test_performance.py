# tests/benchmarks/test_performance.py
"""
Performance benchmarks for scalability testing.

Run with: pytest tests/benchmarks/ --benchmark-only -v
"""

import pytest
import asyncio
import tempfile
from pathlib import Path
from time import time
from chunking.ast_parser import ASTParser
from static_analysis.tool_executor import ToolExecutor


class TestChunkingPerformance:
    """Benchmark AST parsing and chunking"""
    
    def test_chunk_small_file(self, benchmark, tmp_path):
        """Benchmark parsing 100 LOC file"""
        parser = ASTParser()
        
        file_path = tmp_path / "small.py"
        code = "\n".join([
            f"def function_{i}():\n    return {i}\n"
            for i in range(50)  # 50 functions ≈ 100 LOC
        ])
        file_path.write_text(code)
        
        result = benchmark(parser.parse_python_file, file_path)
        
        assert len(result) == 50
    
    def test_chunk_medium_file(self, benchmark, tmp_path):
        """Benchmark parsing 1000 LOC file"""
        parser = ASTParser()
        
        file_path = tmp_path / "medium.py"
        code = "\n".join([
            f"def function_{i}():\n    return {i}\n"
            for i in range(500)  # 500 functions ≈ 1000 LOC
        ])
        file_path.write_text(code)
        
        result = benchmark(parser.parse_python_file, file_path)
        
        assert len(result) == 500
    
    def test_chunk_large_file(self, benchmark, tmp_path):
        """Benchmark parsing 10K LOC file"""
        parser = ASTParser()
        
        file_path = tmp_path / "large.py"
        code = "\n".join([
            f"def function_{i}():\n    return {i}\n"
            for i in range(5000)  # 5000 functions ≈ 10K LOC
        ])
        file_path.write_text(code)
        
        result = benchmark(parser.parse_python_file, file_path)
        
        assert len(result) == 5000
    
    def test_chunk_very_large_file(self, benchmark, tmp_path):
        """Benchmark parsing 100K LOC file"""
        parser = ASTParser()
        
        file_path = tmp_path / "very_large.py"
        code = "\n".join([
            f"def function_{i}():\n    x = {i}\n    return x + 1\n"
            for i in range(25000)  # 25K functions ≈ 100K LOC
        ])
        file_path.write_text(code)
        
        result = benchmark(parser.parse_python_file, file_path)
        
        assert len(result) == 25000


class TestParallelExecution:
    """Benchmark parallel processing"""
    
    @pytest.mark.asyncio
    async def test_serial_vs_parallel_execution(self):
        """Compare serial vs parallel agent execution"""
        
        async def simulate_agent_call(chunk_id: str):
            """Simulate LLM API call with 100ms latency"""
            await asyncio.sleep(0.1)
            return f"result_{chunk_id}"
        
        chunks = [f"chunk_{i}" for i in range(100)]
        
        # Serial execution
        start_serial = time()
        serial_results = []
        for chunk in chunks:
            result = await simulate_agent_call(chunk)
            serial_results.append(result)
        serial_time = time() - start_serial
        
        # Parallel execution
        start_parallel = time()
        parallel_results = await asyncio.gather(
            *[simulate_agent_call(c) for c in chunks]
        )
        parallel_time = time() - start_parallel
        
        # Parallel should be much faster
        speedup = serial_time / parallel_time
        assert speedup > 5  # Should be >5x faster
        assert len(parallel_results) == 100
        
        print(f"\nSerial time: {serial_time:.2f}s")
        print(f"Parallel time: {parallel_time:.2f}s")
        print(f"Speedup: {speedup:.1f}x")
    
    @pytest.mark.asyncio
    async def test_bounded_parallel_execution(self):
        """Test parallel execution with concurrency limits"""
        
        max_concurrent = 10
        total_tasks = 100
        
        semaphore = asyncio.Semaphore(max_concurrent)
        active_count = {"current": 0, "max": 0}
        
        async def bounded_task(task_id: int):
            async with semaphore:
                active_count["current"] += 1
                active_count["max"] = max(
                    active_count["max"],
                    active_count["current"]
                )
                
                await asyncio.sleep(0.01)
                
                active_count["current"] -= 1
                return task_id
        
        start = time()
        results = await asyncio.gather(
            *[bounded_task(i) for i in range(total_tasks)]
        )
        elapsed = time() - start
        
        # Should never exceed max concurrent
        assert active_count["max"] <= max_concurrent
        assert len(results) == total_tasks
        
        print(f"\nMax concurrent: {active_count['max']}/{max_concurrent}")
        print(f"Total time: {elapsed:.2f}s")


class TestMemoryUsage:
    """Benchmark memory efficiency"""
    
    def test_memory_with_large_codebase(self, tmp_path):
        """Test memory usage with large codebase"""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        
        # Measure baseline
        baseline_mb = process.memory_info().rss / 1024 / 1024
        
        parser = ASTParser()
        chunks = []
        
        # Parse 10 large files
        for file_num in range(10):
            file_path = tmp_path / f"file_{file_num}.py"
            code = "\n".join([
                f"def function_{i}():\n    return {i}\n"
                for i in range(1000)
            ])
            file_path.write_text(code)
            
            file_chunks = parser.parse_python_file(file_path)
            chunks.extend(file_chunks)
        
        # Measure after parsing
        peak_mb = process.memory_info().rss / 1024 / 1024
        delta_mb = peak_mb - baseline_mb
        
        # Should not use excessive memory
        assert delta_mb < 100  # Less than 100MB increase
        assert len(chunks) == 10000
        
        print(f"\nBaseline: {baseline_mb:.1f}MB")
        print(f"Peak: {peak_mb:.1f}MB")
        print(f"Delta: {delta_mb:.1f}MB")


class TestScalability:
    """Test system scalability"""
    
    def test_linear_scaling_with_file_count(self, tmp_path):
        """Test that processing time scales linearly with file count"""
        parser = ASTParser()
        
        times = []
        file_counts = [10, 20, 40, 80]
        
        for count in file_counts:
            files = []
            for i in range(count):
                file_path = tmp_path / f"file_{i}.py"
                code = "\n".join([
                    f"def func_{j}():\n    return {j}\n"
                    for j in range(100)
                ])
                file_path.write_text(code)
                files.append(file_path)
            
            # Time parsing all files
            start = time()
            for file_path in files:
                parser.parse_python_file(file_path)
            elapsed = time() - start
            
            times.append(elapsed)
        
        # Calculate scaling factor
        # Time should roughly double when file count doubles
        ratio_1_2 = times[1] / times[0]
        ratio_2_3 = times[2] / times[1]
        
        # Should be close to 2.0 (linear scaling)
        assert 1.5 < ratio_1_2 < 2.5
        assert 1.5 < ratio_2_3 < 2.5
        
        print(f"\nTimes for {file_counts} files: {[f'{t:.3f}s' for t in times]}")
        print(f"Scaling ratios: {ratio_1_2:.2f}, {ratio_2_3:.2f}")
    
    def test_chunking_throughput(self, tmp_path):
        """Measure lines of code processed per second"""
        parser = ASTParser()
        
        # Create 100 files with 1000 LOC each = 100K LOC total
        files = []
        for i in range(100):
            file_path = tmp_path / f"file_{i}.py"
            code = "\n".join([
                f"def function_{j}():\n    return {j}\n"
                for j in range(500)  # 500 functions ≈ 1000 LOC
            ])
            file_path.write_text(code)
            files.append(file_path)
        
        # Time parsing
        start = time()
        total_chunks = 0
        for file_path in files:
            chunks = parser.parse_python_file(file_path)
            total_chunks += len(chunks)
        elapsed = time() - start
        
        # Calculate throughput
        total_loc = 100000  # 100K LOC
        loc_per_second = total_loc / elapsed
        
        # Should process at least 10K LOC/second
        assert loc_per_second > 10000
        
        print(f"\nProcessed {total_loc:,} LOC in {elapsed:.2f}s")
        print(f"Throughput: {loc_per_second:,.0f} LOC/second")
        print(f"Total chunks: {total_chunks:,}")


class TestComplexityCalculation:
    """Benchmark complexity calculation"""
    
    def test_complexity_calculation_speed(self, benchmark, tmp_path):
        """Benchmark cyclomatic complexity calculation"""
        parser = ASTParser()
        
        file_path = tmp_path / "complex.py"
        # Create function with high complexity
        code = """
def complex_function(n):
    result = 0
    for i in range(n):
        if i % 2 == 0:
            if i % 3 == 0:
                if i % 5 == 0:
                    result += i * 3
                else:
                    result += i * 2
            else:
                result += i
        else:
            if i % 7 == 0:
                result -= i
            else:
                result += i // 2
    return result
""" * 100  # Repeat 100 times
        
        file_path.write_text(code)
        
        result = benchmark(parser.parse_python_file, file_path)
        
        # Should calculate complexity for all chunks
        assert all(c.complexity > 0 for c in result)


class TestDependencyGraphPerformance:
    """Benchmark dependency graph construction"""
    
    def test_dependency_graph_construction(self, benchmark, tmp_path):
        """Benchmark building dependency graph"""
        from chunking.dependency_graph import DependencyGraph
        from chunking.ast_parser import ASTParser
        
        parser = ASTParser()
        
        # Create files with dependencies
        files = []
        for i in range(50):
            file_path = tmp_path / f"module_{i}.py"
            imports = [f"import module_{j}" for j in range(i)]
            code = "\n".join(imports + [
                f"\ndef function_{i}():",
                f"    return module_{i-1}.function_{i-1}()" if i > 0 else "    return 42"
            ])
            file_path.write_text(code)
            files.append(file_path)
        
        # Parse all files
        all_chunks = []
        for file_path in files:
            chunks = parser.parse_python_file(file_path)
            all_chunks.extend(chunks)
        
        # Benchmark graph construction
        def build_graph():
            graph_builder = DependencyGraph()
            return graph_builder.build_from_chunks(all_chunks)
        
        graph = benchmark(build_graph)
        
        # Verify graph was built
        assert graph.number_of_nodes() > 0


if __name__ == "__main__":
    # Run with: pytest tests/benchmarks/ --benchmark-only -v
    pytest.main([__file__, "--benchmark-only", "-v"])