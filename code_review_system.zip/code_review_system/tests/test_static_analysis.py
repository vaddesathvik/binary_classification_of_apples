# tests/test_static_analysis.py
"""
Tests for static analysis tool execution and finding normalization.
"""

import pytest
from pathlib import Path
from static_analysis.tool_executor import (
    ToolExecutor, PylintWrapper, BanditWrapper, RadonWrapper, ToolFinding
)
from static_analysis.normalizer import FindingNormalizer


class TestPylintWrapper:
    """Test Pylint static analyzer wrapper"""
    
    @pytest.fixture
    def pylint_wrapper(self):
        return PylintWrapper()
    
    @pytest.fixture
    def code_with_issues(self, tmp_path):
        """Create Python file with known Pylint issues"""
        file_path = tmp_path / "quality_issues.py"
        file_path.write_text("""
def unused_variable():
    x = 42  # Unused variable
    y = 10
    return y

def missing_docstring():
    return 42

def too_many_branches(n):
    if n == 1: return "one"
    elif n == 2: return "two"
    elif n == 3: return "three"
    elif n == 4: return "four"
    elif n == 5: return "five"
    elif n == 6: return "six"
    elif n == 7: return "seven"
    elif n == 8: return "eight"
    elif n == 9: return "nine"
    elif n == 10: return "ten"
    elif n == 11: return "eleven"
    elif n == 12: return "twelve"
    else: return "other"

def undefined_variable():
    return undefined_name  # NameError

import sys
import os
import sys  # Duplicate import
""")
        return file_path
    
    @pytest.mark.asyncio
    async def test_pylint_finds_issues(self, pylint_wrapper, code_with_issues):
        """Test that Pylint detects code quality issues"""
        findings = await pylint_wrapper.analyze(code_with_issues)
        
        # Should find multiple issues
        assert len(findings) > 0
        
        # All findings should be ToolFinding instances
        assert all(isinstance(f, ToolFinding) for f in findings)
        
        # All should be from pylint
        assert all(f.tool == "pylint" for f in findings)
    
    @pytest.mark.asyncio
    async def test_pylint_severity_mapping(self, pylint_wrapper, code_with_issues):
        """Test that Pylint severities are correctly mapped"""
        findings = await pylint_wrapper.analyze(code_with_issues)
        
        # Check severity mapping
        severities = [f.severity for f in findings]
        assert all(s in ['critical', 'high', 'medium', 'low', 'info'] for s in severities)
    
    @pytest.mark.asyncio
    async def test_pylint_handles_valid_code(self, pylint_wrapper, tmp_path):
        """Test Pylint on perfectly valid code"""
        valid_file = tmp_path / "valid.py"
        valid_file.write_text("""
'''A perfectly valid module'''

def hello_world():
    '''Say hello'''
    return "Hello, World!"
""")
        
        findings = await pylint_wrapper.analyze(valid_file)
        
        # Should find very few or no issues
        assert len(findings) <= 2  # May have minor style suggestions


class TestBanditWrapper:
    """Test Bandit security analyzer wrapper"""
    
    @pytest.fixture
    def bandit_wrapper(self):
        return BanditWrapper()
    
    @pytest.fixture
    def vulnerable_code(self, tmp_path):
        """Create Python file with known security vulnerabilities"""
        file_path = tmp_path / "vulnerable.py"
        file_path.write_text("""
import os
import pickle
import subprocess

def sql_injection(user_input):
    # SQL injection vulnerability
    query = f"SELECT * FROM users WHERE name = '{user_input}'"
    return query

def command_injection(user_input):
    # Command injection
    os.system(f"ls {user_input}")
    subprocess.call(f"echo {user_input}", shell=True)

def insecure_deserialization(data):
    # Insecure pickle
    obj = pickle.loads(data)
    return obj

def hardcoded_password():
    # Hardcoded credentials
    password = "admin123"
    api_key = "sk-1234567890abcdef"
    return password

def insecure_temp_file():
    # Insecure temp file
    import tempfile
    temp = tempfile.mktemp()
    return temp

def eval_injection(user_code):
    # Code injection via eval
    return eval(user_code)

try:
    dangerous_operation()
except:
    # Bare except
    pass

import hashlib
hashlib.md5(b"data")  # Weak hash
""")
        return file_path
    
    @pytest.mark.asyncio
    async def test_bandit_finds_vulnerabilities(self, bandit_wrapper, vulnerable_code):
        """Test that Bandit detects security issues"""
        findings = await bandit_wrapper.analyze(vulnerable_code)
        
        # Should find multiple security issues
        assert len(findings) > 0
        
        # All findings should be security category
        assert all(f.category == "security" for f in findings)
        assert all(f.tool == "bandit" for f in findings)
    
    @pytest.mark.asyncio
    async def test_bandit_severity_levels(self, bandit_wrapper, vulnerable_code):
        """Test Bandit severity classification"""
        findings = await bandit_wrapper.analyze(vulnerable_code)
        
        # Should have various severity levels
        severities = [f.severity for f in findings]
        
        # At least some high/critical issues
        assert any(s in ['critical', 'high'] for s in severities)
    
    @pytest.mark.asyncio
    async def test_bandit_confidence_scores(self, bandit_wrapper, vulnerable_code):
        """Test that Bandit provides confidence scores"""
        findings = await bandit_wrapper.analyze(vulnerable_code)
        
        # All findings should have confidence scores
        assert all(0.0 <= f.confidence <= 1.0 for f in findings)
    
    @pytest.mark.asyncio
    async def test_bandit_handles_safe_code(self, bandit_wrapper, tmp_path):
        """Test Bandit on secure code"""
        safe_file = tmp_path / "safe.py"
        safe_file.write_text("""
import hashlib

def safe_function(data: str) -> str:
    '''Process data securely'''
    # Use strong hash
    hashed = hashlib.sha256(data.encode()).hexdigest()
    return hashed

def parameterized_query(user_id: int):
    '''Use parameterized queries (simulated)'''
    query = "SELECT * FROM users WHERE id = ?"
    params = (user_id,)
    return query, params
""")
        
        findings = await bandit_wrapper.analyze(safe_file)
        
        # Should find few or no issues
        assert len(findings) <= 1


class TestRadonWrapper:
    """Test Radon complexity analyzer wrapper"""
    
    @pytest.fixture
    def radon_wrapper(self):
        return RadonWrapper()
    
    @pytest.fixture
    def complex_code(self, tmp_path):
        """Create file with high cyclomatic complexity"""
        file_path = tmp_path / "complex.py"
        file_path.write_text("""
def simple_function():
    return 42

def moderate_complexity(x):
    if x > 0:
        if x > 10:
            return "high"
        return "low"
    return "negative"

def high_complexity(data):
    result = []
    for item in data:
        if item > 0:
            if item % 2 == 0:
                if item < 100:
                    result.append(item * 2)
                else:
                    result.append(item)
            else:
                if item < 50:
                    result.append(item + 1)
                else:
                    result.append(item - 1)
        else:
            if item < -10:
                result.append(0)
            else:
                result.append(item)
    return result

def very_high_complexity(n):
    if n == 1: return 1
    elif n == 2: return 2
    elif n == 3: return 3
    elif n == 4: return 4
    elif n == 5: return 5
    elif n == 6: return 6
    elif n == 7: return 7
    elif n == 8: return 8
    elif n == 9: return 9
    elif n == 10: return 10
    elif n == 11: return 11
    elif n == 12: return 12
    elif n == 13: return 13
    elif n == 14: return 14
    elif n == 15: return 15
    else: return 0
""")
        return file_path
    
    @pytest.mark.asyncio
    async def test_radon_detects_complexity(self, radon_wrapper, complex_code):
        """Test that Radon detects high complexity"""
        findings = await radon_wrapper.analyze(complex_code)
        
        # Should flag high complexity functions
        assert len(findings) > 0
        
        # All should be from radon
        assert all(f.tool == "radon" for f in findings)
        assert all(f.category == "maintainability" for f in findings)
    
    @pytest.mark.asyncio
    async def test_radon_ignores_simple_code(self, radon_wrapper, tmp_path):
        """Test that Radon doesn't flag simple code"""
        simple_file = tmp_path / "simple.py"
        simple_file.write_text("""
def add(a, b):
    return a + b

def greet(name):
    return f"Hello, {name}"
""")
        
        findings = await radon_wrapper.analyze(simple_file)
        
        # Should not flag simple functions
        assert len(findings) == 0


class TestToolExecutor:
    """Test parallel tool execution"""
    
    @pytest.fixture
    def executor(self):
        return ToolExecutor()
    
    @pytest.fixture
    def test_file(self, tmp_path):
        """Create test file with various issues"""
        file_path = tmp_path / "test.py"
        file_path.write_text("""
import os

def vulnerable_function(user_input):
    # Multiple issues: SQL injection + complexity
    query = f"SELECT * FROM users WHERE name = '{user_input}'"
    
    if user_input:
        if len(user_input) > 10:
            if user_input.startswith('admin'):
                return query + " AND role = 'admin'"
            else:
                return query + " AND role = 'user'"
        else:
            return query
    return None

unused_variable = 42
""")
        return file_path
    
    @pytest.mark.asyncio
    async def test_execute_all_tools(self, executor, test_file):
        """Test executing all tools in parallel"""
        enabled_tools = ['pylint', 'bandit', 'radon']
        
        results = await executor.analyze_file(test_file, enabled_tools)
        
        # Should have results from all tools
        assert len(results) == 3
        assert 'pylint' in results
        assert 'bandit' in results
        assert 'radon' in results
    
    @pytest.mark.asyncio
    async def test_executor_handles_failures(self, executor, tmp_path):
        """Test that executor handles tool failures gracefully"""
        nonexistent_file = tmp_path / "nonexistent.py"
        
        results = await executor.analyze_file(
            nonexistent_file,
            ['pylint', 'bandit']
        )
        
        # Should return results dict even if tools fail
        assert isinstance(results, dict)
    
    @pytest.mark.asyncio
    async def test_parallel_execution_speed(self, executor, test_file):
        """Test that parallel execution is faster than serial"""
        import time
        
        enabled_tools = ['pylint', 'bandit', 'radon']
        
        # Time parallel execution
        start = time.time()
        await executor.analyze_file(test_file, enabled_tools)
        parallel_time = time.time() - start
        
        # Parallel execution should complete in reasonable time
        assert parallel_time < 10.0  # Should be much faster than 10s


class TestFindingNormalizer:
    """Test finding normalization and deduplication"""
    
    @pytest.fixture
    def normalizer(self):
        return FindingNormalizer()
    
    def test_deduplicate_exact_duplicates(self, normalizer):
        """Test deduplication of exact duplicate findings"""
        findings = [
            ToolFinding(
                tool="pylint",
                file_path="test.py",
                line=10,
                severity="high",
                category="correctness",
                message="Undefined variable",
                confidence=1.0
            ),
            ToolFinding(
                tool="pylint",
                file_path="test.py",
                line=10,
                severity="high",
                category="correctness",
                message="Undefined variable",
                confidence=1.0
            )
        ]
        
        normalized = normalizer.normalize_all_findings({"pylint": findings})
        
        # Should deduplicate to single finding
        assert len(normalized) == 1
    
    def test_merge_findings_from_multiple_tools(self, normalizer):
        """Test merging findings from different tools at same location"""
        findings_by_tool = {
            "pylint": [
                ToolFinding(
                    tool="pylint",
                    file_path="test.py",
                    line=10,
                    severity="medium",
                    category="style",
                    message="Line too long",
                    confidence=0.8
                )
            ],
            "bandit": [
                ToolFinding(
                    tool="bandit",
                    file_path="test.py",
                    line=10,
                    severity="high",
                    category="security",
                    message="SQL injection",
                    confidence=0.9
                )
            ]
        }
        
        normalized = normalizer.normalize_all_findings(findings_by_tool)
        
        # Should merge but keep most severe
        assert len(normalized) == 2  # Different categories
    
    def test_confidence_boost_on_agreement(self, normalizer):
        """Test confidence boost when multiple tools agree"""
        findings_by_tool = {
            "tool1": [
                ToolFinding(
                    tool="tool1",
                    file_path="test.py",
                    line=10,
                    severity="high",
                    category="security",
                    message="Security issue",
                    confidence=0.7
                )
            ],
            "tool2": [
                ToolFinding(
                    tool="tool2",
                    file_path="test.py",
                    line=10,
                    severity="high",
                    category="security",
                    message="Security issue",
                    confidence=0.7
                )
            ]
        }
        
        normalized = normalizer.normalize_all_findings(findings_by_tool)
        
        # Confidence should be boosted
        assert len(normalized) == 1
        assert normalized[0].confidence > 0.7
    
    def test_keep_most_severe(self, normalizer):
        """Test that most severe finding is kept when merging"""
        findings = [
            ToolFinding(
                tool="tool1",
                file_path="test.py",
                line=10,
                severity="low",
                category="style",
                message="Issue",
                confidence=0.8
            ),
            ToolFinding(
                tool="tool2",
                file_path="test.py",
                line=10,
                severity="critical",
                category="security",
                message="Critical issue",
                confidence=0.9
            )
        ]
        
        normalized = normalizer._merge_duplicate_findings(findings)
        
        # Should keep critical severity
        assert normalized[0].severity == "critical"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])