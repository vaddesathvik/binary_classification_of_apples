from typing import Dict, List, Optional
import json
import redis
from dataclasses import asdict


class ChunkMetadataStore:
    """
    Store and retrieve chunk metadata.
    Uses Redis for fast access during analysis.
    """
    
    def __init__(self, redis_url: str = "redis://localhost:6379"):
        self.redis_client = redis.from_url(redis_url, decode_responses=True)
    
    def store_chunk(self, chunk: 'CodeChunk'):
        """Store chunk metadata"""
        key = f"chunk:{chunk.chunk_id}"
        value = json.dumps(asdict(chunk))
        self.redis_client.set(key, value, ex=3600)  # 1 hour TTL
    
    def get_chunk(self, chunk_id: str) -> Optional['CodeChunk']:
        """Retrieve chunk by ID"""
        key = f"chunk:{chunk_id}"
        value = self.redis_client.get(key)
        
        if value:
            from chunking.ast_parser import CodeChunk
            data = json.loads(value)
            return CodeChunk(**data)
        
        return None
    
    def store_file_chunks(self, file_path: str, chunk_ids: List[str]):
        """Store mapping of file to its chunks"""
        key = f"file:{file_path}"
        value = json.dumps(chunk_ids)
        self.redis_client.set(key, value, ex=3600)
    
    def get_file_chunks(self, file_path: str) -> List[str]:
        """Get all chunk IDs for a file"""
        key = f"file:{file_path}"
        value = self.redis_client.get(key)
        
        if value:
            return json.loads(value)
        
        return []
    
    def clear_all(self):
        """Clear all chunk metadata"""
        for key in self.redis_client.scan_iter("chunk:*"):
            self.redis_client.delete(key)
        for key in self.redis_client.scan_iter("file:*"):
            self.redis_client.delete(key)