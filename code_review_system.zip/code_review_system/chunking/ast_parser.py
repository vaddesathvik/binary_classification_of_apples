import ast
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class CodeChunk:
    """Represents a semantic chunk of code (function, class, module)"""
    chunk_id: str
    file_path: str
    start_line: int
    end_line: int
    chunk_type: str  # "function", "class", "module"
    name: str
    content: str
    parent_chunk_id: Optional[str] = None
    complexity: int = 0
    dependencies: List[str] = None
    
    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []


class ASTParser:
    """
    AST-based code chunking for semantic analysis.
    This is CRITICAL for handling large files - we chunk by AST nodes,
    not by arbitrary token limits.
    """
    
    def parse_python_file(self, file_path: Path) -> List[CodeChunk]:
        """
        Parse Python file into semantic chunks.
        
        Args:
            file_path: Path to Python file
            
        Returns:
            List of code chunks
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            source = f.read()
            lines = source.splitlines()
        
        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            # File has syntax errors - return whole file as one chunk
            return [CodeChunk(
                chunk_id=f"{file_path}:0",
                file_path=str(file_path),
                start_line=1,
                end_line=len(lines),
                chunk_type="module",
                name=file_path.stem,
                content=source
            )]
        
        chunks = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                chunk = self._create_chunk_from_node(
                    node, lines, file_path, "function"
                )
                chunks.append(chunk)
            
            elif isinstance(node, ast.ClassDef):
                chunk = self._create_chunk_from_node(
                    node, lines, file_path, "class"
                )
                chunks.append(chunk)
        
        # If no functions/classes found, return whole file
        if not chunks:
            chunks.append(CodeChunk(
                chunk_id=f"{file_path}:0",
                file_path=str(file_path),
                start_line=1,
                end_line=len(lines),
                chunk_type="module",
                name=file_path.stem,
                content=source
            ))
        
        return chunks
    
    def _create_chunk_from_node(
        self,
        node: ast.AST,
        lines: List[str],
        file_path: Path,
        chunk_type: str
    ) -> CodeChunk:
        """Create chunk from AST node"""
        start_line = node.lineno
        end_line = node.end_lineno or start_line
        
        content = '\n'.join(lines[start_line - 1:end_line])
        
        # Calculate cyclomatic complexity
        complexity = self._calculate_complexity(node)
        
        # Extract dependencies (imports, calls)
        dependencies = self._extract_dependencies(node)
        
        return CodeChunk(
            chunk_id=f"{file_path}:{start_line}",
            file_path=str(file_path),
            start_line=start_line,
            end_line=end_line,
            chunk_type=chunk_type,
            name=node.name,
            content=content,
            complexity=complexity,
            dependencies=dependencies
        )
    
    def _calculate_complexity(self, node: ast.AST) -> int:
        """Calculate cyclomatic complexity of AST node"""
        complexity = 1  # Base complexity
        
        for child in ast.walk(node):
            # Decision points increase complexity
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        
        return complexity
    
    def _extract_dependencies(self, node: ast.AST) -> List[str]:
        """Extract function/module dependencies from node"""
        deps = set()
        
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                if isinstance(child.func, ast.Name):
                    deps.add(child.func.id)
                elif isinstance(child.func, ast.Attribute):
                    deps.add(child.func.attr)
        
        return list(deps)
