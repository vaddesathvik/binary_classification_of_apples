import networkx as nx
from typing import List, Dict, Set, Tuple
from pathlib import Path
import ast


class DependencyGraph:
    """
    Build and analyze dependency graph for entire codebase.
    Essential for detecting architectural issues like circular dependencies.
    """
    
    def __init__(self):
        self.graph = nx.DiGraph()
        self.import_map = {}  # file -> list of imports
        self.call_graph = {}  # function -> list of called functions
    
    def build_from_chunks(self, chunks: List['CodeChunk']) -> nx.DiGraph:
        """
        Build dependency graph from code chunks.
        
        Args:
            chunks: List of code chunks
            
        Returns:
            NetworkX directed graph
        """
        # Add all chunks as nodes
        for chunk in chunks:
            self.graph.add_node(
                chunk.chunk_id,
                file_path=chunk.file_path,
                name=chunk.name,
                type=chunk.chunk_type
            )
        
        # Build import dependencies
        for chunk in chunks:
            self._extract_imports(chunk)
        
        # Build call dependencies
        for chunk in chunks:
            self._extract_calls(chunk)
        
        return self.graph
    
    def _extract_imports(self, chunk: 'CodeChunk'):
        """Extract import statements from chunk"""
        try:
            tree = ast.parse(chunk.content)
            imports = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append(node.module)
            
            self.import_map[chunk.chunk_id] = imports
            
            # Add edges for imports
            for imp in imports:
                self.graph.add_edge(
                    chunk.chunk_id,
                    imp,
                    type='import'
                )
        except:
            pass
    
    def _extract_calls(self, chunk: 'CodeChunk'):
        """Extract function calls from chunk"""
        try:
            tree = ast.parse(chunk.content)
            calls = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        calls.append(node.func.id)
                    elif isinstance(node.func, ast.Attribute):
                        calls.append(node.func.attr)
            
            self.call_graph[chunk.chunk_id] = calls
            
            # Add edges for calls
            for call in calls:
                # Try to find the called function in our graph
                for node_id in self.graph.nodes():
                    node_data = self.graph.nodes[node_id]
                    if node_data.get('name') == call:
                        self.graph.add_edge(
                            chunk.chunk_id,
                            node_id,
                            type='call'
                        )
        except:
            pass
    
    def detect_circular_dependencies(self) -> List[List[str]]:
        """Detect circular dependencies in the graph"""
        cycles = list(nx.simple_cycles(self.graph))
        return cycles
    
    def get_dependency_chain(self, chunk_id: str) -> List[str]:
        """Get all dependencies for a chunk"""
        if chunk_id not in self.graph:
            return []
        
        descendants = nx.descendants(self.graph, chunk_id)
        return list(descendants)
    
    def get_coupling_metrics(self) -> Dict[str, float]:
        """Calculate coupling metrics for the codebase"""
        if len(self.graph.nodes()) == 0:
            return {}
        
        metrics = {}
        
        # Afferent coupling (incoming dependencies)
        for node in self.graph.nodes():
            in_degree = self.graph.in_degree(node)
            metrics[f"{node}_afferent"] = in_degree
        
        # Efferent coupling (outgoing dependencies)
        for node in self.graph.nodes():
            out_degree = self.graph.out_degree(node)
            metrics[f"{node}_efferent"] = out_degree
        
        return metrics

