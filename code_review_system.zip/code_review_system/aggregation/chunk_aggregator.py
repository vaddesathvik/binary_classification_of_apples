from typing import List, Dict
from collections import defaultdict


class ChunkAggregator:
    """
    Aggregate findings from chunk-level analysis.
    """
    
    def aggregate_chunk_issues(
        self,
        agent_outputs: List['AgentOutput'],
        chunk: 'CodeChunk'
    ) -> 'ChunkAnalysis':
        """
        Aggregate all agent outputs for a single chunk.
        
        Args:
            agent_outputs: Outputs from all agents for this chunk
            chunk: The code chunk
            
        Returns:
            ChunkAnalysis with aggregated issues
        """
        from models.schemas import ChunkAnalysis
        
        # Collect all issues
        all_issues = []
        for output in agent_outputs:
            all_issues.extend(output.issues)
        
        # Calculate chunk-level metrics
        complexity_score = chunk.complexity
        maintainability = self._calculate_maintainability(chunk, all_issues)
        
        return ChunkAnalysis(
            chunk_id=chunk.chunk_id,
            file_path=chunk.file_path,
            start_line=chunk.start_line,
            end_line=chunk.end_line,
            issues=all_issues,
            complexity_score=complexity_score,
            maintainability_index=maintainability
        )
    
    def _calculate_maintainability(
        self,
        chunk: 'CodeChunk',
        issues: List['Issue']
    ) -> float:
        """
        Calculate maintainability index (0-100).
        Higher is better.
        """
        # Start with 100
        score = 100.0
        
        # Reduce based on complexity
        if chunk.complexity > 10:
            score -= (chunk.complexity - 10) * 2
        
        # Reduce based on issues
        for issue in issues:
            if issue.severity.value == "critical":
                score -= 15
            elif issue.severity.value == "high":
                score -= 10
            elif issue.severity.value == "medium":
                score -= 5
            elif issue.severity.value == "low":
                score -= 2
        
        # Reduce based on size
        lines = chunk.end_line - chunk.start_line
        if lines > 100:
            score -= (lines - 100) * 0.1
        
        return max(0.0, min(100.0, score))
