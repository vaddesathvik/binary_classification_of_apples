from typing import List, Dict
from pathlib import Path


class ModuleAggregator:
    """
    Aggregate findings at module/package level.
    Detects architectural issues that span multiple files.
    """
    
    def aggregate_module_issues(
        self,
        file_analyses: List['FileAnalysis'],
        dependency_graph: 'DependencyGraph'
    ) -> Dict[str, List['Issue']]:
        """
        Identify module-level issues.
        
        Args:
            file_analyses: List of file analyses in module
            dependency_graph: Dependency graph for codebase
            
        Returns:
            Dict of module_name -> architectural issues
        """
        module_issues = {}
        
        # Group files by module (directory)
        modules = self._group_by_module(file_analyses)
        
        for module_name, files in modules.items():
            issues = []
            
            # Check for circular dependencies within module
            cycles = self._detect_module_cycles(files, dependency_graph)
            if cycles:
                issues.extend(self._create_cycle_issues(cycles))
            
            # Check for module coupling
            coupling = self._calculate_module_coupling(files, dependency_graph)
            if coupling > 0.7:  # High coupling threshold
                issues.append(self._create_coupling_issue(module_name, coupling))
            
            # Check for module cohesion
            cohesion = self._calculate_module_cohesion(files)
            if cohesion < 0.3:  # Low cohesion threshold
                issues.append(self._create_cohesion_issue(module_name, cohesion))
            
            module_issues[module_name] = issues
        
        return module_issues
    
    def _group_by_module(
        self,
        file_analyses: List['FileAnalysis']
    ) -> Dict[str, List['FileAnalysis']]:
        """Group files by their module (directory)"""
        modules = {}
        
        for file_analysis in file_analyses:
            path = Path(file_analysis.file_path)
            module_name = path.parent.name if path.parent.name else "root"
            
            if module_name not in modules:
                modules[module_name] = []
            
            modules[module_name].append(file_analysis)
        
        return modules
    
    def _detect_module_cycles(
        self,
        files: List['FileAnalysis'],
        dependency_graph: 'DependencyGraph'
    ) -> List[List[str]]:
        """Detect circular dependencies within module"""
        cycles = dependency_graph.detect_circular_dependencies()
        
        # Filter to only cycles within this module
        file_paths = {f.file_path for f in files}
        module_cycles = []
        
        for cycle in cycles:
            cycle_files = {dependency_graph.graph.nodes[node]['file_path'] 
                          for node in cycle}
            
            # If all files in cycle are in this module
            if cycle_files.issubset(file_paths):
                module_cycles.append(cycle)
        
        return module_cycles
    
    def _calculate_module_coupling(
        self,
        files: List['FileAnalysis'],
        dependency_graph: 'DependencyGraph'
    ) -> float:
        """Calculate coupling between module and rest of system"""
        # Count external dependencies
        external_deps = 0
        internal_edges = 0
        
        file_paths = {f.file_path for f in files}
        
        for file_analysis in files:
            # Count outgoing edges
            for node in dependency_graph.graph.nodes():
                node_file = dependency_graph.graph.nodes[node].get('file_path')
                
                if node_file == file_analysis.file_path:
                    for successor in dependency_graph.graph.successors(node):
                        successor_file = dependency_graph.graph.nodes[successor].get('file_path')
                        
                        if successor_file in file_paths:
                            internal_edges += 1
                        else:
                            external_deps += 1
        
        total = external_deps + internal_edges
        if total == 0:
            return 0.0
        
        return external_deps / total
    
    def _calculate_module_cohesion(self, files: List['FileAnalysis']) -> float:
        """Calculate cohesion within module"""
        # Simple heuristic: ratio of internal to total issues
        internal_issues = 0
        total_issues = 0
        
        for file_analysis in files:
            for issue in file_analysis.aggregated_issues:
                total_issues += 1
                # Issues that reference other files in module indicate cohesion
                if any(f.file_path in issue.description 
                      for f in files):
                    internal_issues += 1
        
        if total_issues == 0:
            return 1.0
        
        return internal_issues / total_issues
    
    def _create_cycle_issues(self, cycles: List[List[str]]) -> List['Issue']:
        """Create issues for circular dependencies"""
        from models.schemas import Issue, Evidence, IssueCategory, Severity, CodeLocation
        
        issues = []
        for i, cycle in enumerate(cycles):
            issue = Issue(
                id=f"circular_dep_{i}",
                category=IssueCategory.MAINTAINABILITY,
                severity=Severity.HIGH,
                title="Circular Dependency Detected",
                description=f"Circular dependency found: {' -> '.join(cycle)}",
                location=CodeLocation(
                    file_path=cycle[0] if cycle else "unknown",
                    start_line=1,
                    end_line=1
                ),
                evidence=[Evidence(
                    source="dependency_graph",
                    raw_output=f"Cycle: {cycle}",
                    confidence=1.0
                )],
                confidence=1.0
            )
            issues.append(issue)
        
        return issues
    
    def _create_coupling_issue(self, module_name: str, coupling: float) -> 'Issue':
        """Create issue for high coupling"""
        from models.schemas import Issue, Evidence, IssueCategory, Severity, CodeLocation
        
        return Issue(
            id=f"high_coupling_{module_name}",
            category=IssueCategory.MAINTAINABILITY,
            severity=Severity.MEDIUM,
            title="High Module Coupling",
            description=f"Module '{module_name}' has high coupling ({coupling:.2f}). "
                       f"Consider reducing external dependencies.",
            location=CodeLocation(
                file_path=module_name,
                start_line=1,
                end_line=1
            ),
            evidence=[Evidence(
                source="module_analyzer",
                raw_output=f"Coupling: {coupling}",
                confidence=0.9
            )],
            confidence=0.9
        )
    
    def _create_cohesion_issue(self, module_name: str, cohesion: float) -> 'Issue':
        """Create issue for low cohesion"""
        from models.schemas import Issue, Evidence, IssueCategory, Severity, CodeLocation
        
        return Issue(
            id=f"low_cohesion_{module_name}",
            category=IssueCategory.MAINTAINABILITY,
            severity=Severity.MEDIUM,
            title="Low Module Cohesion",
            description=f"Module '{module_name}' has low cohesion ({cohesion:.2f}). "
                       f"Consider splitting into more focused modules.",
            location=CodeLocation(
                file_path=module_name,
                start_line=1,
                end_line=1
            ),
            evidence=[Evidence(
                source="module_analyzer",
                raw_output=f"Cohesion: {cohesion}",
                confidence=0.9
            )],
            confidence=0.9
        )