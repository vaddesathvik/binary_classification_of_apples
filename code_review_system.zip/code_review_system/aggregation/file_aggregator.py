from typing import List


class FileAggregator:
    """
    Aggregate findings from file-level analysis.
    """
    
    def aggregate_file_issues(
        self,
        chunk_analyses: List['ChunkAnalysis'],
        file_path: str,
        language: str
    ) -> 'FileAnalysis':
        """
        Aggregate chunk analyses into file-level analysis.
        
        Args:
            chunk_analyses: List of chunk analyses for this file
            file_path: Path to file
            language: Programming language
            
        Returns:
            FileAnalysis with aggregated issues
        """
        from models.schemas import FileAnalysis
        from aggregation.system_aggregator import SystemAggregator
        
        # Collect all issues from chunks
        all_issues = []
        for chunk in chunk_analyses:
            all_issues.extend(chunk.issues)
        
        # Deduplicate issues
        aggregator = SystemAggregator()
        unique_issues = aggregator._deduplicate_issues(all_issues)
        
        # Calculate file-level risk
        file_risk = aggregator._calculate_file_risk(unique_issues)
        
        # Calculate total lines
        total_lines = sum(
            c.end_line - c.start_line
            for c in chunk_analyses
        )
        
        return FileAnalysis(
            file_path=file_path,
            language=language,
            total_lines=total_lines,
            chunk_analyses=chunk_analyses,
            aggregated_issues=unique_issues,
            file_risk_score=file_risk
        )