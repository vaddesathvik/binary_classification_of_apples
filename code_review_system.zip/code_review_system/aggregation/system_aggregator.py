from typing import List, Dict
from collections import defaultdict


class SystemAggregator:
    """
    Hierarchical aggregation: Chunk → File → Module → System
    
    This is critical for detecting architectural issues that span
    multiple files (e.g., circular dependencies, architectural violations)
    """
    
    def aggregate_to_file_level(
        self,
        chunk_analyses: List[ChunkAnalysis]
    ) -> FileAnalysis:
        """Aggregate chunk-level findings to file level"""
        
        if not chunk_analyses:
            return None
        
        # Group issues by category
        all_issues = []
        for chunk in chunk_analyses:
            all_issues.extend(chunk.issues)
        
        # Remove duplicates (same issue flagged by multiple chunks)
        unique_issues = self._deduplicate_issues(all_issues)
        
        # Calculate file-level metrics
        file_risk = self._calculate_file_risk(unique_issues)
        
        return FileAnalysis(
            file_path=chunk_analyses[0].file_path,
            language=chunk_analyses[0].language,
            total_lines=sum(c.end_line - c.start_line for c in chunk_analyses),
            chunk_analyses=chunk_analyses,
            aggregated_issues=unique_issues,
            file_risk_score=file_risk
        )
    
    def aggregate_to_repository_level(
        self,
        file_analyses: List[FileAnalysis]
    ) -> RepositoryAnalysis:
        """Aggregate file-level findings to repository level"""
        
        all_issues = []
        for file_analysis in file_analyses:
            all_issues.extend(file_analysis.aggregated_issues)
        
        # Count by severity
        severity_counts = defaultdict(int)
        for issue in all_issues:
            severity_counts[issue.severity.value] += 1
        
        # Calculate overall risk score
        risk_score = self._calculate_repository_risk(all_issues)
        
        # Calculate confidence (average of verified issues)
        verified_issues = [i for i in all_issues if i.is_verified]
        avg_confidence = sum(i.confidence for i in verified_issues) / max(
            len(verified_issues), 1
        )
        
        return RepositoryAnalysis(
            repository_name="analyzed_repo",
            analysis_id=str(uuid.uuid4()),
            file_analyses=file_analyses,
            total_issues=len(all_issues),
            critical_issues=severity_counts["critical"],
            high_issues=severity_counts["high"],
            medium_issues=severity_counts["medium"],
            low_issues=severity_counts["low"],
            overall_risk_score=risk_score,
            confidence=avg_confidence,
            files_analyzed=len(file_analyses),
            lines_analyzed=sum(f.total_lines for f in file_analyses)
        )
    
    def _deduplicate_issues(self, issues: List[Issue]) -> List[Issue]:
        """Remove duplicate issues"""
        seen = set()
        unique = []
        
        for issue in issues:
            key = f"{issue.location.file_path}:{issue.location.start_line}:{issue.title}"
            if key not in seen:
                seen.add(key)
                unique.append(issue)
        
        return unique
    
    def _calculate_file_risk(self, issues: List[Issue]) -> float:
        """Calculate risk score for file (0-100)"""
        if not issues:
            return 0.0
        
        severity_weights = {
            "critical": 10.0,
            "high": 5.0,
            "medium": 2.0,
            "low": 0.5,
            "info": 0.1
        }
        
        total_risk = sum(
            severity_weights.get(issue.severity.value, 0) * issue.confidence
            for issue in issues
        )
        
        # Normalize to 0-100 scale
        return min(total_risk, 100.0)
    
    def _calculate_repository_risk(self, all_issues: List[Issue]) -> float:
        """Calculate overall repository risk"""
        if not all_issues:
            return 0.0
        
        # Weight by severity and confidence
        critical = sum(1 for i in all_issues if i.severity.value == "critical")
        high = sum(1 for i in all_issues if i.severity.value == "high")
        
        # Risk formula: emphasize critical issues
        risk = (critical * 20 + high * 10) / max(len(all_issues), 1)
        
        return min(risk, 100.0)