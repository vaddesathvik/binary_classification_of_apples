import subprocess
import json
import asyncio
from typing import Dict, List, Any, Optional
from pathlib import Path
from dataclasses import dataclass


@dataclass
class ToolFinding:
    """Normalized finding from static analysis tool"""
    tool: str
    file_path: str
    line: int
    severity: str
    category: str
    message: str
    rule_id: Optional[str] = None
    confidence: float = 1.0


class StaticAnalysisTool:
    """Base class for static analysis tool wrappers"""
    
    async def analyze(self, file_path: Path) -> List[ToolFinding]:
        raise NotImplementedError


class PylintWrapper(StaticAnalysisTool):
    """Wrapper for Pylint static analyzer"""
    
    SEVERITY_MAP = {
        'error': 'high',
        'warning': 'medium',
        'refactor': 'low',
        'convention': 'info',
    }
    
    async def analyze(self, file_path: Path) -> List[ToolFinding]:
        """Run Pylint and parse results"""
        try:
            result = await asyncio.create_subprocess_exec(
                'pylint',
                '--output-format=json',
                '--disable=all',
                '--enable=E,W,R',  # Errors, Warnings, Refactors
                str(file_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await result.communicate()
            
            if stdout:
                pylint_output = json.loads(stdout.decode())
                return self._parse_pylint_output(pylint_output, file_path)
            
            return []
        except Exception as e:
            print(f"Pylint analysis failed for {file_path}: {e}")
            return []
    
    def _parse_pylint_output(
        self, 
        output: List[Dict], 
        file_path: Path
    ) -> List[ToolFinding]:
        """Convert Pylint output to normalized findings"""
        findings = []
        
        for item in output:
            finding = ToolFinding(
                tool='pylint',
                file_path=str(file_path),
                line=item.get('line', 1),
                severity=self.SEVERITY_MAP.get(item.get('type', 'info'), 'info'),
                category='correctness',
                message=item.get('message', ''),
                rule_id=item.get('message-id'),
            )
            findings.append(finding)
        
        return findings


class BanditWrapper(StaticAnalysisTool):
    """Wrapper for Bandit security analyzer"""
    
    SEVERITY_MAP = {
        'HIGH': 'critical',
        'MEDIUM': 'high',
        'LOW': 'medium',
    }
    
    async def analyze(self, file_path: Path) -> List[ToolFinding]:
        """Run Bandit and parse results"""
        try:
            result = await asyncio.create_subprocess_exec(
                'bandit',
                '-f', 'json',
                str(file_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await result.communicate()
            
            if stdout:
                bandit_output = json.loads(stdout.decode())
                return self._parse_bandit_output(bandit_output, file_path)
            
            return []
        except Exception as e:
            print(f"Bandit analysis failed for {file_path}: {e}")
            return []
    
    def _parse_bandit_output(
        self,
        output: Dict,
        file_path: Path
    ) -> List[ToolFinding]:
        """Convert Bandit output to normalized findings"""
        findings = []
        
        for result in output.get('results', []):
            finding = ToolFinding(
                tool='bandit',
                file_path=str(file_path),
                line=result.get('line_number', 1),
                severity=self.SEVERITY_MAP.get(
                    result.get('issue_severity', 'LOW'),
                    'medium'
                ),
                category='security',
                message=result.get('issue_text', ''),
                rule_id=result.get('test_id'),
                confidence=result.get('issue_confidence', 1.0) / 3.0  # Normalize
            )
            findings.append(finding)
        
        return findings


class RadonWrapper(StaticAnalysisTool):
    """Wrapper for Radon complexity analyzer"""
    
    async def analyze(self, file_path: Path) -> List[ToolFinding]:
        """Run Radon and parse results"""
        try:
            # Get cyclomatic complexity
            result = await asyncio.create_subprocess_exec(
                'radon',
                'cc',
                '-j',
                str(file_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await result.communicate()
            
            if stdout:
                radon_output = json.loads(stdout.decode())
                return self._parse_radon_output(radon_output, file_path)
            
            return []
        except Exception as e:
            print(f"Radon analysis failed for {file_path}: {e}")
            return []
    
    def _parse_radon_output(
        self,
        output: Dict,
        file_path: Path
    ) -> List[ToolFinding]:
        """Convert Radon output to normalized findings"""
        findings = []
        
        for file_data in output.values():
            for func in file_data:
                complexity = func.get('complexity', 0)
                
                # Flag high complexity
                if complexity > 10:
                    severity = 'high' if complexity > 20 else 'medium'
                    finding = ToolFinding(
                        tool='radon',
                        file_path=str(file_path),
                        line=func.get('lineno', 1),
                        severity=severity,
                        category='maintainability',
                        message=f"High cyclomatic complexity: {complexity}",
                        rule_id='CC',
                    )
                    findings.append(finding)
        
        return findings


class ToolExecutor:
    """Execute all static analysis tools in parallel"""
    
    def __init__(self):
        self.tools = {
            'pylint': PylintWrapper(),
            'bandit': BanditWrapper(),
            'radon': RadonWrapper(),
        }
    
    async def analyze_file(
        self,
        file_path: Path,
        enabled_tools: List[str]
    ) -> Dict[str, List[ToolFinding]]:
        """
        Run all enabled tools on a file in parallel.
        
        Args:
            file_path: Path to file
            enabled_tools: List of tool names to run
            
        Returns:
            Dict mapping tool name to findings
        """
        tasks = []
        tool_names = []
        
        for tool_name in enabled_tools:
            if tool_name in self.tools:
                tasks.append(self.tools[tool_name].analyze(file_path))
                tool_names.append(tool_name)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        findings_by_tool = {}
        for tool_name, result in zip(tool_names, results):
            if isinstance(result, Exception):
                print(f"Tool {tool_name} failed: {result}")
                findings_by_tool[tool_name] = []
            else:
                findings_by_tool[tool_name] = result
        
        return findings_by_tool

