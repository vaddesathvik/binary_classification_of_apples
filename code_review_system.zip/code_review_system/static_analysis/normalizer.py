from typing import List, Dict
from collections import defaultdict


class FindingNormalizer:
    """
    Normalize findings from different static analysis tools
    into a common format.
    """
    
    def normalize_all_findings(
        self,
        findings_by_tool: Dict[str, List['ToolFinding']]
    ) -> List['ToolFinding']:
        """
        Normalize and deduplicate findings from all tools.
        
        Args:
            findings_by_tool: Dict of tool_name -> findings
            
        Returns:
            Deduplicated list of normalized findings
        """
        all_findings = []
        
        for tool, findings in findings_by_tool.items():
            all_findings.extend(findings)
        
        # Deduplicate by location
        deduplicated = self._deduplicate_findings(all_findings)
        
        # Merge confidence scores for duplicates
        merged = self._merge_duplicate_findings(deduplicated)
        
        return merged
    
    def _deduplicate_findings(
        self,
        findings: List['ToolFinding']
    ) -> List['ToolFinding']:
        """Remove exact duplicates"""
        seen = set()
        unique = []
        
        for finding in findings:
            key = (finding.file_path, finding.line, finding.message)
            if key not in seen:
                seen.add(key)
                unique.append(finding)
        
        return unique
    
    def _merge_duplicate_findings(
        self,
        findings: List['ToolFinding']
    ) -> List['ToolFinding']:
        """
        Merge findings at same location from different tools.
        Boost confidence when multiple tools agree.
        """
        location_map = defaultdict(list)
        
        for finding in findings:
            key = (finding.file_path, finding.line)
            location_map[key].append(finding)
        
        merged = []
        
        for location, location_findings in location_map.items():
            if len(location_findings) == 1:
                merged.append(location_findings[0])
            else:
                # Multiple tools found issues at same location
                # Keep the most severe one with boosted confidence
                most_severe = max(
                    location_findings,
                    key=lambda f: self._severity_weight(f.severity)
                )
                
                # Boost confidence based on number of tools agreeing
                boost = 1.0 + (len(location_findings) - 1) * 0.1
                most_severe.confidence = min(most_severe.confidence * boost, 1.0)
                
                merged.append(most_severe)
        
        return merged
    
    def _severity_weight(self, severity: str) -> int:
        """Convert severity to numeric weight"""
        weights = {
            'critical': 4,
            'high': 3,
            'medium': 2,
            'low': 1,
            'info': 0
        }
        return weights.get(severity, 0)