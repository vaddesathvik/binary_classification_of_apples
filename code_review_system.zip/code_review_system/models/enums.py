from enum import Enum


class AnalysisStatus(str, Enum):
    """Status of an analysis job"""
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SourceType(str, Enum):
    """Type of code source"""
    GIT = "git"
    ZIP = "zip"
    PR = "pr"
    FOLDER = "folder"


class Language(str, Enum):
    """Supported programming languages"""
    PYTHON = "python"
    JAVA = "java"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    CPP = "cpp"
    C = "c"
    GO = "go"
    RUST = "rust"