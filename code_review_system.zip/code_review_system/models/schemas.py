from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class IssueCategory(str, Enum):
    SECURITY = "security"
    PERFORMANCE = "performance"
    MAINTAINABILITY = "maintainability"
    CORRECTNESS = "correctness"
    STYLE = "style"
    TESTING = "testing"


class CodeLocation(BaseModel):
    file_path: str
    start_line: int
    end_line: int
    function_name: Optional[str] = None
    class_name: Optional[str] = None


class Evidence(BaseModel):
    source: str  # "pylint", "bandit", "agent_security", etc.
    raw_output: str
    confidence: float = Field(ge=0.0, le=1.0)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class Issue(BaseModel):
    id: str
    category: IssueCategory
    severity: Severity
    title: str
    description: str
    location: CodeLocation
    evidence: List[Evidence]
    confidence: float = Field(ge=0.0, le=1.0)
    suggested_fix: Optional[str] = None
    fixed_code: Optional[str] = None
    cwe_id: Optional[str] = None  # For security issues
    
    @property
    def is_verified(self) -> bool:
        """Issue is verified if it has tool evidence AND high confidence"""
        has_tool_evidence = any(
            e.source in ["pylint", "bandit", "radon", "semgrep"]
            for e in self.evidence
        )
        return has_tool_evidence and self.confidence >= 0.7


class ChunkAnalysis(BaseModel):
    chunk_id: str
    file_path: str
    start_line: int
    end_line: int
    issues: List[Issue] = []
    complexity_score: Optional[float] = None
    maintainability_index: Optional[float] = None


class FileAnalysis(BaseModel):
    file_path: str
    language: str
    total_lines: int
    chunk_analyses: List[ChunkAnalysis] = []
    aggregated_issues: List[Issue] = []
    file_risk_score: float = 0.0


class RepositoryAnalysis(BaseModel):
    repository_name: str
    analysis_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    file_analyses: List[FileAnalysis] = []
    
    # Aggregated metrics
    total_issues: int = 0
    critical_issues: int = 0
    high_issues: int = 0
    medium_issues: int = 0
    low_issues: int = 0
    
    overall_risk_score: float = 0.0
    confidence: float = 0.0
    
    # Cost tracking
    total_cost: float = 0.0
    processing_time_seconds: float = 0.0
    
    # Metadata
    languages_detected: List[str] = []
    files_analyzed: int = 0
    lines_analyzed: int = 0


class AnalysisRequest(BaseModel):
    source_type: str  # "git", "zip", "pr", "folder"
    source_location: str
    filters: Optional[Dict[str, Any]] = None
    custom_rules: Optional[List[Dict[str, Any]]] = None