from typing import Tuple, Dict, Any
from enum import Enum


class ModelSelector:
    """
    Select optimal model based on task requirements and constraints.
    """
    
    def __init__(self, cost_budget: float = None):
        self.cost_budget = cost_budget
        self.total_spent = 0.0
    
    def select_model(
        self,
        task_type: str,
        priority: str = "balanced",
        max_tokens: int = 4000
    ) -> Tuple[str, str]:
        """
        Select model based on task and constraints.
        
        Args:
            task_type: Type of task (security, performance, etc.)
            priority: "quality", "cost", or "balanced"
            max_tokens: Max tokens needed
            
        Returns:
            Tuple of (model_name, provider)
        """
        
        # If over budget, always use cheapest model
        if self.cost_budget and self.total_spent >= self.cost_budget:
            return "gpt-3.5-turbo", "openai"
        
        # Quality priority: use best models
        if priority == "quality":
            if task_type == "security":
                return "claude-opus-4-20250514", "anthropic"
            else:
                return "claude-sonnet-4-20250514", "anthropic"
        
        # Cost priority: use cheapest models
        elif priority == "cost":
            return "gpt-3.5-turbo", "openai"
        
        # Balanced: use routing config
        else:
            from config.llm_router_config import TASK_MODEL_MAPPING, TaskType
            
            try:
                task_enum = TaskType(task_type)
                model = TASK_MODEL_MAPPING.get(
                    task_enum,
                    "claude-sonnet-4-20250514"
                )
                
                if "claude" in model:
                    return model, "anthropic"
                else:
                    return model, "openai"
            except:
                return "claude-sonnet-4-20250514", "anthropic"
    
    def record_cost(self, cost: float):
        """Record cost of API call"""
        self.total_spent += cost
    
    def get_remaining_budget(self) -> float:
        """Get remaining budget"""
        if self.cost_budget:
            return max(0, self.cost_budget - self.total_spent)
        return float('inf')