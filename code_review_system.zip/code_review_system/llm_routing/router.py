from typing import Optional, Dict, Any
from enum import Enum
import anthropic
import openai
from config.llm_router_config import TaskType, TASK_MODEL_MAPPING, MODEL_COSTS


class LLMProvider(str, Enum):
    ANTHROPIC = "anthropic"
    OPENAI = "openai"


class MultiLLMRouter:
    """
    Intelligent LLM routing based on task requirements.
    
    Design Philosophy:
    - Route security tasks to most powerful model (Opus)
    - Route performance tasks to code-specialized model (GPT-4)
    - Route style/syntax to cost-efficient models
    - Track costs across all calls
    - Implement caching for repeated queries
    """
    
    def __init__(self, anthropic_key: str, openai_key: str):
        self.anthropic_client = anthropic.Anthropic(api_key=anthropic_key)
        self.openai_client = openai.OpenAI(api_key=openai_key)
        
        self.total_cost = 0.0
        self.call_count = 0
        self.cache = {}  # Simple in-memory cache
    
    def select_model(self, task_type: TaskType) -> tuple[str, LLMProvider]:
        """
        Select optimal model for task type.
        
        Args:
            task_type: Type of analysis task
            
        Returns:
            Tuple of (model_name, provider)
        """
        model_name = TASK_MODEL_MAPPING.get(task_type, "claude-sonnet-4-20250514")
        
        if "claude" in model_name:
            return model_name, LLMProvider.ANTHROPIC
        else:
            return model_name, LLMProvider.OPENAI
    
    async def call_llm(
        self,
        task_type: TaskType,
        prompt: str,
        max_tokens: int = 4000,
        temperature: float = 0.0,
        use_cache: bool = True
    ) -> Dict[str, Any]:
        """
        Call appropriate LLM with routing logic.
        
        Args:
            task_type: Type of task
            prompt: Input prompt
            max_tokens: Maximum response tokens
            temperature: Sampling temperature
            use_cache: Whether to use cache
            
        Returns:
            LLM response as dict
        """
        
        # Check cache
        cache_key = f"{task_type}:{hash(prompt)}"
        if use_cache and cache_key in self.cache:
            return self.cache[cache_key]
        
        model, provider = self.select_model(task_type)
        
        try:
            if provider == LLMProvider.ANTHROPIC:
                response = await self._call_anthropic(
                    model, prompt, max_tokens, temperature
                )
            else:
                response = await self._call_openai(
                    model, prompt, max_tokens, temperature
                )
            
            # Cache result
            if use_cache:
                self.cache[cache_key] = response
            
            # Track cost
            cost = self._calculate_cost(model, prompt, response)
            self.total_cost += cost
            self.call_count += 1
            
            return response
            
        except Exception as e:
            # Fallback to cheaper model on error
            print(f"Primary model failed, falling back: {e}")
            return await self._fallback_call(prompt, max_tokens, temperature)
    
    async def _call_anthropic(
        self,
        model: str,
        prompt: str,
        max_tokens: int,
        temperature: float
    ) -> Dict[str, Any]:
        """Call Anthropic API"""
        
        message = self.anthropic_client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        # Parse response
        content = message.content[0].text
        
        # Try to parse as JSON
        import json
        try:
            return json.loads(content)
        except:
            # If not JSON, return as text
            return {"text": content}
    
    async def _call_openai(
        self,
        model: str,
        prompt: str,
        max_tokens: int,
        temperature: float
    ) -> Dict[str, Any]:
        """Call OpenAI API"""
        
        response = self.openai_client.chat.completions.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}  # Force JSON
        )
        
        import json
        return json.loads(response.choices[0].message.content)
    
    async def _fallback_call(
        self,
        prompt: str,
        max_tokens: int,
        temperature: float
    ) -> Dict[str, Any]:
        """Fallback to cheapest reliable model"""
        try:
            return await self._call_anthropic(
                "claude-sonnet-4-20250514",
                prompt,
                max_tokens,
                temperature
            )
        except:
            return {"error": "All models failed", "issues": []}
    
    def _calculate_cost(
        self,
        model: str,
        prompt: str,
        response: Dict[str, Any]
    ) -> float:
        """Calculate API call cost"""
        
        # Rough token estimation (4 chars = 1 token)
        input_tokens = len(prompt) / 4
        output_tokens = len(str(response)) / 4
        
        costs = MODEL_COSTS.get(model, {"input": 0.001, "output": 0.002})
        
        cost = (
            (input_tokens / 1000) * costs["input"] +
            (output_tokens / 1000) * costs["output"]
        )
        
        return cost
    
    def get_cost_report(self) -> Dict[str, Any]:
        """Get cost tracking report"""
        return {
            "total_cost": round(self.total_cost, 4),
            "total_calls": self.call_count,
            "avg_cost_per_call": round(
                self.total_cost / max(self.call_count, 1), 4
            ),
            "cache_size": len(self.cache)
        }