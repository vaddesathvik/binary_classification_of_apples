from typing import Dict, List
from collections import defaultdict
import json


class CostOptimizer:
    """
    Track and optimize LLM API costs.
    """
    
    def __init__(self):
        self.costs_by_agent = defaultdict(float)
        self.costs_by_model = defaultdict(float)
        self.call_counts = defaultdict(int)
        self.cache_hits = 0
        self.cache_misses = 0
    
    def record_call(
        self,
        agent_name: str,
        model: str,
        cost: float,
        cache_hit: bool = False
    ):
        """Record an API call"""
        if not cache_hit:
            self.costs_by_agent[agent_name] += cost
            self.costs_by_model[model] += cost
            self.call_counts[model] += 1
            self.cache_misses += 1
        else:
            self.cache_hits += 1
    
    def get_cost_report(self) -> Dict[str, Any]:
        """Generate cost analysis report"""
        total_cost = sum(self.costs_by_model.values())
        total_calls = sum(self.call_counts.values())
        
        return {
            "total_cost": round(total_cost, 4),
            "total_calls": total_calls,
            "cache_hit_rate": round(
                self.cache_hits / max(self.cache_hits + self.cache_misses, 1),
                2
            ),
            "costs_by_agent": dict(self.costs_by_agent),
            "costs_by_model": dict(self.costs_by_model),
            "avg_cost_per_call": round(
                total_cost / max(total_calls, 1),
                4
            ),
            "most_expensive_agent": max(
                self.costs_by_agent.items(),
                key=lambda x: x[1],
                default=("none", 0)
            )[0]
        }
    
    def suggest_optimizations(self) -> List[str]:
        """Suggest cost optimization strategies"""
        suggestions = []
        
        total_cost = sum(self.costs_by_model.values())
        
        # Check cache hit rate
        cache_rate = self.cache_hits / max(self.cache_hits + self.cache_misses, 1)
        if cache_rate < 0.3:
            suggestions.append(
                "Low cache hit rate. Enable more aggressive caching."
            )
        
        # Check most expensive agent
        if self.costs_by_agent:
            most_expensive = max(self.costs_by_agent.items(), key=lambda x: x[1])
            if most_expensive[1] > total_cost * 0.4:
                suggestions.append(
                    f"{most_expensive[0]} accounts for >40% of costs. "
                    f"Consider using a cheaper model or reducing calls."
                )
        
        # Check model usage
        opus_cost = self.costs_by_model.get("claude-opus-4-20250514", 0)
        if opus_cost > total_cost * 0.5:
            suggestions.append(
                "Opus usage is high. Route more tasks to Sonnet where possible."
            )
        
        return suggestions
